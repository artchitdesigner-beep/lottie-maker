# Flipshope Lottie kit

Python toolkit that makes Lottie animations in the Flipshope style: banners, motion posters,
animated emoji, stickers, loaders, and owl character animations. Output is pure vector Lottie JSON that
plays on web (lottie-web), Android, iOS and React Native.

## Setup (once per session, ~30 s)
```bash
bash setup.sh            # pip: lottie svgpathtools fonttools brotli playwright · npm: lottie-web, fonts, Fluent icons
```

## Files
| File | What it is |
|---|---|
| `STYLE.md` | Brand motion rules. Read before designing. |
| `brandkit.py` | `Scene` builder for any composition (text, cards, pills, icons, owl, confetti, presets) |
| `owl-source-v4.svg` + `gen*.py`, `expr.py`, `anims5.py`, `faces6.py`, `assets_lib.py` | The owl rig and its 27 animations |
| `check.py` | Validate + preview: errors, size budget, mobile-unsafe features, loop seam, PNG frame strips |
| `board.py` | Build an HTML preview page for several Lottie files |
| `examples/` | Banner, emoji and poster recipes |

## Scene API (brandkit.py)
```python
from brandkit import Scene, C, owl_library
s = Scene(w, h, frames=150, mode='cycle')   # 'loop' (seamless), 'once', 'cycle' (fade out at end)
```
Every element method takes motion options:
`anim='pop'|'rise'|'drop'|'slide-left'|'slide-right'|'fade'|'stamp'|'spin-in'`, `t0=` start frame,
`d=` duration, `loop='float'|'pulse'|'wiggle'|'swing'|'breathe'|'spin'`, `loop_amp=`, `loop_period=`.

| Method | Notes |
|---|---|
| `background(color='surface' \| gradient=('primary','navy'), angle=90)` | Always bottom layer |
| `glow(cx, cy, r, color='accent', alpha=.35)` | Soft radial light behind the hero |
| `blob(cx, cy, r, color, alpha)` | Soft ambient circle (good with `loop='float'`) |
| `card(x, y, w, h, radius=28, color='card', shadow=True)` | Rounded card with soft shadow |
| `text(str, x, y, size, color, font='display'\|'body', weight, align, max_width, stagger=)` | Vector text. Returns (layer, w, h). `stagger` animates word by word |
| `pill(str, x, y, size, color, text_color, align)` / `button(...)` | Rounded label / CTA. Returns (layer, w, h) |
| `icon(name, cx, cy, size, recolor={'#hex':'#hex'})` | Fluent Emoji Flat icon by name (e.g. `fire`, `bell`, `shopping-bags`, `money-bag`, `party-popper`, `gift`, `rocket`) |
| `sparkle(cx, cy, R)` / `rays(cx, cy, angle)` / `confetti(cx, cy, t0, count)` | Brand accents |
| `owl(key, cx, cy, size, anim=, t0=, flip=False)` | Drop in an owl clip; loops inside the scene |
| `add_layer(nm, shapes, anchor=...)` | Escape hatch for custom shapes (see `gen.py` helpers `el`, `rc`, `sh`, `fl`, `sk`, `gr`, `K`) |
| `save(path)` | Write JSON |

Owl keys: `idle-blink walking search-analyze price-alert celebrate`,
`expr-{neutral,happy,star-struck,wink,shocked,thinking,calm,unimpressed,in-love,cheerful}`,
`scene-{onboarding,empty-state,feature-discovery,success,error-no-deals,campaigns}`,
`face-{idle,loading,typing,alert,deal-found,offline}`.
Clip lengths (frames): face-idle 120, face-loading 48, face-typing 90, face-alert 72, face-deal-found 60,
face-offline 120; expr 60–120; body 32–100. For `mode='loop'`, make `frames` a multiple of the clip length.

## New owl animations
For a new owl pose/action, write it with the rig: `gen5.build(name, N, spec, face=..., fx=...)` (full body),
`faces6.face_anim(...)` (head only), or `anims5.ub(...)` (upper body). See `anims5.py` and `faces6.py`
for every spec key (`root_p`, `root_s`, `head_r`, `face_p`, `wingL/R`, `wingL/R_curl`, `prop`, `look`,
`closed`, ...). Eyes: `pupil_group`, `arc('L'|'R','up'|'down')`, `brow`, `lid`, `blink`.

## Check every output
```bash
python3 check.py out/my.json        # must print OK, within budget, no warnings, loop: seamless
```
Then look at `out/my.sheet.png` and `out/my.png` before delivering.
