# Flipshope motion style

The rules every Flipshope Lottie follows, with or without the owl. When in doubt, match what's here.

## Personality
Friendly, smart, on the shopper's side. Motion is **bouncy but quick**: things pop in with a small
overshoot and settle fast. Never slow, floaty or corporate. Never aggressive or flashy.

## Colour (use token names in code)
| Token | Hex | Use |
|---|---|---|
| primary | #1E4DFF | Main brand blue, buttons, headlines on light |
| navy | #0B1640 | Dark backgrounds, gradient end |
| ink | #0F1A3C | Text on light |
| accent | #FFC107 | Highlights, pills, rays, sparkles, CTA on dark |
| surface | #F3F6FF | Light backgrounds |
| owl / cape / beak | #0148BD / #FFD402 / #FFD92D | Character only. Don't recolour the owl |
| green / red | #1F9D55 / #E5383B | Price down / urgent or hot. Small amounts only |
| confetti | purple, accent, blue, pink, green | Celebrations only |

Backgrounds: either `surface` (light) or a `primary → navy` gradient (dark). One accent colour per piece.

## Type
- **Display**: Baloo 2 ExtraBold (800). Headlines, numbers, stickers. Tight line height (0.95–1.05).
- **Body**: Figtree 500–700. Sub-lines, labels, buttons.
- Text is always converted to vector shapes (`Scene.text`), never a Lottie text layer.
- Headline max 2 lines, about 6 words. Sentence case. No full stops in buttons.

## Shapes
Rounded everything: pills (fully round), cards radius 24–36, no sharp corners. Soft two-step shadow
under cards (`Scene.card`). Soft radial glow (`Scene.glow`) behind the hero element instead of hard
lighting. Icons: Fluent Emoji Flat only (MIT licence), via `Scene.icon`.

## Motion
| Thing | Rule |
|---|---|
| Entrances | `pop` for objects and badges, `rise` for text, `drop` for pills/tags, `stamp` for stickers/labels |
| Easing | Overshoot (`back`) for pops; ease-out for rises; never linear except spins and confetti |
| Durations | 6 frames tiny, 10 small, 16 default, 24 large (30 fps) |
| Stagger | 3–4 frames between words, 4–8 between elements. Order: label → headline → hero → body → CTA |
| Idle | After entering, things breathe: `float` 6–10 px, `pulse` 4–6 %, `wiggle` 3–6° |
| Celebration | `confetti` + `rays` + sparkles, max one burst per loop |
| Loop | Emoji/stickers: `mode='loop'` (seamless). Banners/posters: `mode='cycle'` (fade out last 10 frames) |

## The owl
- Use only the library animations (`Scene.owl('key', ...)`). Never redraw or recolour him.
- Face clips (`face-*`) for small spaces and emoji; `expr-*` for stickers and medium; full body for posters.
- He looks toward the content or the CTA, not away from it (use `flip=True` to mirror).
- Max one owl per piece. He supports the message, never covers text.
- Emotion must match the message: deal/success → `face-deal-found`, `expr-happy`, `celebrate`;
  alert → `face-alert`, `price-alert`; loading → `face-loading`, `search-analyze`; error → `scene-error-no-deals`.

## Sizes and budgets
| Format | Canvas | Length | Budget |
|---|---|---|---|
| Animated emoji / sticker | 512×512 | 1–3 s seamless loop | ≤ 60 KB |
| In-app banner | 1200×400 or 1080×360 | 4–6 s | ≤ 150 KB |
| Web hero / OG | 1200×630 | 4–6 s | ≤ 150 KB |
| Story / reel cover | 1080×1920 | 5–8 s | ≤ 250 KB |
| Motion poster (portrait) | 1080×1350 | 5–8 s | ≤ 250 KB |
| Loader / spinner | 240×240 | 1–2 s seamless | ≤ 40 KB |

## Don'ts
No text layers, images, expressions, blur or effects (they break on mobile). No more than 3 typefaces
weights in one piece. No pure black. No gradients on text. Don't put the owl on a busy background.
