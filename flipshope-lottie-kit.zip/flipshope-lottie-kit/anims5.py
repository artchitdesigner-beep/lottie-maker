"""All animations on the v5 rig: 5 body actions, 10 upper-body expressions, 6 use-case scenes."""
import json, math, os
from gen import K, sh, fl, sk, gr, layer, hx, YEL, WHITE
from gen4 import rays, arc, brow, ell, PUPIL_L, PUPIL_R, ROOT_PIV, C_PUPIL, C_HEAD, confetti
from gen5 import build, pupil_group, free_icon, pop_keys, icon, YELLOWIFY, PIV, TIP, bent_point, HERE
from expr import lid, blink, offs

P0 = list(ROOT_PIV)
def up(d): return [ROOT_PIV[0], ROOT_PIV[1] - d]
def LK(x, y): return (round(x * 2.25, 1), round(y * 2.25, 1))
def FP(dx): return [375 + dx, 280]

BODY = {}
# ---------------- full-body actions ----------------
N = 90
BODY['idle-blink'] = build('Idle Blink', N, {
    'root_s': [(0, [100, 100]), (10, [104, 95]), (15, [96, 105], 'out'), (22, [99, 101]), (27, [105, 95], 'out'),
               (33, [100, 100]), (60, [101, 99]), (90, [100, 100])],
    'root_p': [(0, P0), (13, P0, 'out'), (20, up(45), 'in'), (27, P0), (90, P0)],
    'head_p': [(0, [375, 470]), (15, [375, 470]), (21, [375, 478]), (29, [375, 462]), (36, [375, 470]), (90, [375, 470])],
    'shadow': [(0, [100, 100]), (13, [100, 100], 'out'), (20, [82, 82], 'in'), (27, [100, 100]), (90, [100, 100])],
    'head_r': [(0, 0), (40, 0), (46, -4), (60, -4), (68, 4), (80, 4), (88, 0), (90, 0)],
    'face_p': [(0, FP(0)), (40, FP(0)), (46, FP(-16)), (60, FP(-16)), (68, FP(16)), (80, FP(16)), (88, FP(0)), (90, FP(0))],
    'wingL': [(0, 0), (12, 0, 'out'), (19, 12), (27, 0), (90, 0)],
    'wingR': [(0, 0), (12, 0, 'out'), (19, -12), (27, 0), (90, 0)],
    'wingL_curl': [(0, 0), (14, 0), (21, 14), (31, -6), (40, 0), (90, 0)],
    'wingR_curl': [(0, 0), (14, 0), (21, -14), (31, 6), (40, 0), (90, 0)],
    'look': [(0, (0, 0)), (40, (0, 0)), (46, LK(-8, 1)), (60, LK(-8, 1)), (68, LK(8, 1)), (80, LK(8, 1)), (88, (0, 0)), (90, (0, 0))],
    'closed': [(62, 66)],
    'lines': [(25, 34)],
    'sparkles': [{'c': (720, 60), 'ang': -50, 'vis': [(20, 44)]}],
})
N = 32
BODY['walking'] = build('Walking', N, {
    'root_p': [(0, P0), (8, up(18)), (16, P0), (24, up(18)), (32, P0)],
    'root_r': [(0, -4), (16, 4), (32, -4)],
    'head_r': [(0, 3), (16, -3), (32, 3)],
    'face_p': [(0, FP(6)), (16, FP(-6)), (32, FP(6))],
    'footR': [(0, [492, 836]), (7, [492, 866]), (25, [492, 866]), (32, [492, 836])],
    'footL': [(0, [262, 866]), (9, [262, 866]), (16, [262, 836]), (23, [262, 866]), (32, [262, 866])],
    'wingL': [(0, 8), (16, -4), (32, 8)], 'wingR': [(0, 4), (16, -8), (32, 4)],
    'wingL_curl': [(0, -8), (16, 10), (32, -8)], 'wingR_curl': [(0, -10), (16, 8), (32, -10)],
    'shadow': [(0, [100, 100]), (8, [95, 100]), (16, [100, 100]), (24, [95, 100]), (32, [100, 100])],
})
N = 100
R1 = -95
BODY['search-analyze'] = build('Search / Analyze', N, {
    'prop': {'kind': 'magnifier', 'raise': R1, 'curl': -35, 'grip': 255},
    'wingR': [(0, 0), (10, 0, 'out'), (22, R1), (36, R1 + 7), (50, R1 - 5), (64, R1 + 5), (78, R1), (82, R1), (94, 0), (100, 0)],
    'wingR_curl': [(0, 0), (10, 0, 'out'), (24, -35), (82, -35), (94, 0), (100, 0)],
    'prop_s': [(0, [0, 0], 'hold'), (14, [0, 0], 'back'), (28, [100, 100]), (80, [100, 100], 'in'), (90, [0, 0], 'hold'), (100, [0, 0])],
    'look': [(0, (0, 0)), (16, (0, 0)), (24, LK(10, -6)), (78, LK(10, -6)), (86, (0, 0)), (100, (0, 0))],
    'face_p': [(0, FP(0)), (16, FP(0)), (26, FP(14)), (78, FP(14)), (88, FP(0)), (100, FP(0))],
    'closed_L': [(46, 58)],
    'head_r': [(0, 0), (20, 0), (30, 5), (76, 5), (86, 0), (100, 0)],
    'root_s': [(0, [100, 100]), (50, [101, 99]), (100, [100, 100])],
    'fx_layers': [free_icon('sparkles', (830, 60), 120, 30, N, s=pop_keys(30, 76, N))],
})
N = 96
BODY['price-alert'] = build('Price Alert', N, {
    'prop': {'kind': 'bell', 'raise': R1, 'curl': -30, 'grip': 250},
    'wingR': [(0, 0), (8, 0, 'out'), (20, R1), (76, R1), (88, 0), (96, 0)],
    'wingR_curl': [(0, 0), (8, 0, 'out'), (22, -30), (76, -30), (88, 0), (96, 0)],
    'prop_s': [(0, [0, 0], 'hold'), (10, [0, 0], 'back'), (22, [100, 100]), (76, [100, 100], 'in'), (84, [0, 0], 'hold'), (96, [0, 0])],
    'prop_r': [(0, 0), (22, 0), (28, 24), (34, -24), (40, 20), (46, -20), (52, 14), (58, -10), (64, 5), (70, 0), (96, 0)],
    'closed': [(36, 54)],
    'look': [(0, (0, 0)), (14, (0, 0)), (22, LK(9, -5)), (74, LK(9, -5)), (84, (0, 0)), (96, (0, 0))],
    'face_p': [(0, FP(0)), (14, FP(0)), (24, FP(12)), (74, FP(12)), (84, FP(0)), (96, FP(0))],
    'root_r': [(0, 0), (24, 0), (28, 2), (32, -2), (36, 2), (40, -2), (44, 0), (96, 0)],
    'fx_layers': [free_icon('sparkles', (840, 150), 120, 30, N, s=pop_keys(26, 70, N))],
})
N = 80
flapL = [(0, 0), (8, 0, 'out'), (16, 95), (20, 80), (24, 98), (28, 82), (32, 95), (40, 82), (48, 96), (56, 84), (62, 92), (72, 0), (80, 0)]
curlL = [(0, 0), (8, 0), (16, 30), (20, -10), (24, 30), (28, -10), (32, 30), (40, -6), (48, 28), (56, -6), (62, 20), (72, 0), (80, 0)]
BODY['celebrate'] = build('Celebrate / Deal Found', N, {
    'root_s': [(0, [100, 100]), (8, [108, 90]), (13, [95, 106], 'out'), (24, [98, 103]), (32, [110, 90], 'out'),
               (40, [97, 103]), (46, [100, 100]), (50, [104, 95]), (54, [97, 104]), (62, [106, 94]), (68, [100, 100]), (80, [100, 100])],
    'root_p': [(0, P0), (10, P0, 'out'), (22, up(105), 'in'), (32, P0), (52, P0, 'out'), (57, up(50), 'in'), (62, P0), (80, P0)],
    'head_p': [(0, [375, 470]), (12, [375, 482]), (22, [375, 456]), (34, [375, 484]), (42, [375, 470]), (80, [375, 470])],
    'shadow': [(0, [100, 100]), (10, [100, 100], 'out'), (22, [62, 62], 'in'), (32, [100, 100]), (52, [100, 100], 'out'),
               (57, [84, 84], 'in'), (62, [100, 100]), (80, [100, 100])],
    'wingL': flapL, 'wingR': [(t, -v, *e) for (t, v, *e) in flapL],
    'wingL_curl': curlL, 'wingR_curl': [(t, -v, *e) for (t, v, *e) in curlL],
    'closed': [(8, 70)],
    'head_r': [(0, 0), (22, -4), (40, 4), (52, -3), (68, 0), (80, 0)],
    'confetti': 14,
    'lines': [(30, 42), (61, 69)],
    'fx_layers': [free_icon('party-popper', (-60, 180), 170, 30, N, s=pop_keys(12, 70, N), r=K([(12, -20), (30, 0), (70, 0)])),
                  free_icon('sparkles', (700, 40), 140, 31, N, s=pop_keys(16, 70, N))],
})

# ---------------- upper-body expressions ----------------
STAGE_U = ((375, 0), (360, 118), 82)
def ub(name, N, spec, face, fx=None):
    return build(name, N, spec, face=face, fx=fx, stage=STAGE_U)

def breathe(N, amt=1.2):
    return {'root_s': [(0, [100, 100]), (N // 2, [100 + amt * 0.5, 100 + amt]), (N, [100, 100])]}

def pulse_keys(N, lo=88, hi=108):
    return K([(0, [lo, lo]), (N // 2, [hi, hi]), (N, [lo, lo])])

EX = {}
N = 120
sb, ab = blink([40, 96], N)
look = [(0, (0, 0)), (20, (0, 0)), (28, (-22, 2)), (52, (-22, 2)), (60, (22, 2)), (84, (22, 2)), (92, (0, 0)), (N, (0, 0))]
EX['neutral'] = ub('Neutral', N, dict(breathe(N), head_r=[(0, 0), (20, 0), (28, -3), (52, -3), (60, 3), (84, 3), (92, 0), (N, 0)],
                                       face_p=[(0, FP(0)), (20, FP(0)), (28, FP(-16)), (52, FP(-16)), (60, FP(16)), (84, FP(16)), (92, FP(0)), (N, FP(0))]), [
    arc('L', 'down', o=ab, w=16, dy=-10), arc('R', 'down', o=ab, w=16, dy=-10),
    pupil_group('L', {'p': offs(PUPIL_L, look), 's': sb, 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, look), 's': sb, 'o': 100})])

N = 60
squish = K([(0, [100, 100]), (15, [104, 112]), (30, [100, 100]), (45, [104, 112]), (60, [100, 100])])
EX['happy'] = ub('Happy', N, {
    'root_p': [(0, P0), (15, up(14), 'in'), (30, P0), (45, up(14), 'in'), (60, P0)],
    'head_r': [(0, -3), (30, 3), (60, -3)], 'face_p': [(0, FP(-6)), (30, FP(6)), (60, FP(-6))],
    'wingL': [(0, 0), (15, 6), (30, 0), (45, 6), (60, 0)], 'wingR': [(0, 0), (15, -6), (30, 0), (45, -6), (60, 0)],
    'wingL_curl': [(0, 0), (15, 12), (30, 0), (45, 12), (60, 0)], 'wingR_curl': [(0, 0), (15, -12), (30, 0), (45, -12), (60, 0)],
}, [arc('L', 'up', s=squish), arc('R', 'up', s=squish)], fx=[rays((650, 60), -50, [], 20, N, loop=True)])

N = 60
def star_pupil(side):
    pc = PUPIL_L if side == 'L' else PUPIL_R
    st_ = gr([icon('star', pc, 92)], 'star', a=pc, p=pc, r=K([(0, -10), (15, 10), (30, -10), (45, 10), (60, -10)]))
    return pupil_group(side, {'p': list(pc), 's': K([(0, [100, 100]), (10, [110, 110]), (20, [100, 100]), (30, [110, 110]), (40, [100, 100]), (60, [100, 100])]), 'o': 100}, extra=[st_], hl=False)
EX['star-struck'] = ub('Star-Struck', N, {
    'root_s': [(0, [100, 100]), (6, [103, 97]), (12, [99, 102]), (20, [100, 100]), (60, [100, 100])],
    'root_p': [(0, P0), (8, up(10), 'in'), (16, P0), (60, P0)],
}, [star_pupil('L'), star_pupil('R')], fx=[free_icon('sparkles', (660, 40), 150, 20, N, s=pulse_keys(N))])

N = 75
wink_s = K([(0, [100, 100]), (4, [100, 100], 'in'), (8, [100, 10], 'hold'), (60, [100, 10], 'out'), (66, [100, 100]), (N, [100, 100])])
wink_o = K([(0, 100, 'hold'), (8, 0, 'hold'), (60, 100, 'hold'), (N, 100)])
arc_o = K([(0, 0, 'hold'), (8, 100, 'hold'), (60, 0, 'hold'), (N, 0)])
EX['wink'] = ub('Wink', N, {'head_r': [(0, 0), (10, 5), (60, 5), (68, 0), (N, 0)], 'face_p': [(0, FP(0)), (10, FP(10)), (60, FP(10)), (68, FP(0)), (N, FP(0))]}, [
    arc('R', 'up', o=arc_o, s=K([(8, [100, 40], 'out'), (12, [100, 100]), (56, [100, 100], 'in'), (60, [100, 40])])),
    pupil_group('R', {'p': list(PUPIL_R), 's': wink_s, 'o': wink_o}),
    pupil_group('L', {'p': offs(PUPIL_L, [(0, (0, 0)), (10, (6, -4)), (60, (6, -4)), (66, (0, 0)), (N, (0, 0))]), 's': [100, 100], 'o': 100}),
], fx=[rays((650, 50), -50, [(8, 62)], 20, N)])

N = 90
shrink = K([(0, [100, 100]), (6, [74, 74], 'out'), (14, [82, 82]), (N, [82, 82])])
EX['shocked'] = ub('Shocked', N, {
    'root_p': [(0, P0), (5, up(30), 'out'), (14, up(-6)), (22, P0), (N, P0)],
    'root_s': [(0, [100, 100]), (5, [96, 105], 'out'), (14, [103, 97]), (22, [100, 100]), (N, [100, 100])],
    'head_p': [(0, [375, 470]), (6, [375, 486]), (16, [375, 460]), (26, [375, 470]), (N, [375, 470])],
    'wingL': [(0, 0), (5, 22, 'out'), (20, 14), (N, 14)], 'wingR': [(0, 0), (5, -22, 'out'), (20, -14), (N, -14)],
    'wingL_curl': [(0, 0), (6, 25, 'out'), (20, 15), (N, 15)], 'wingR_curl': [(0, 0), (6, -25, 'out'), (20, -15), (N, -15)],
}, [pupil_group('L', {'p': offs(PUPIL_L, [(0, (0, 0)), (6, (6, -8)), (N, (6, -8))]), 's': shrink, 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, [(0, (0, 0)), (6, (-6, -8)), (N, (-6, -8))]), 's': shrink, 'o': 100})],
   fx=[free_icon('double-exclamation-mark', (590, -40), 170, 20, N, recolor=YELLOWIFY, s=pop_keys(2, None, N),
                 r=K([(12, 0), (16, -8), (20, 8), (24, 0), (N, 0)]))])

N = 120
th = [(0, (30, -34)), (40, (38, -30)), (80, (24, -38)), (N, (30, -34))]
EX['thinking'] = ub('Thinking', N, {
    'wingR': [(0, 158), (30, 161), (60, 155), (90, 161), (N, 158)],
    'wingR_curl': [(0, -6), (60, -10), (N, -6)],
    'wingR_s': [(0, [68, 68]), (N, [68, 68])],
    'head_r': [(0, 5), (60, 8), (N, 5)], 'face_p': [(0, FP(10)), (60, FP(14)), (N, FP(10))],
    **breathe(N),
}, [lid('L', -18), brow('R', 'raised', p=K([(0, [481.02, 193.86]), (60, [481.02, 186]), (N, [481.02, 193.86])])),
    pupil_group('L', {'p': offs(PUPIL_L, th), 's': [100, 100], 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, th), 's': [100, 100], 'o': 100})],
   fx=[free_icon('red-question-mark', (650, -10), 170, 20, N, recolor=YELLOWIFY, r=K([(0, -10), (60, 10), (N, -10)]), s=pulse_keys(N, 95, 108))])

N = 90
EX['calm'] = ub('Calm', N, dict(breathe(N, 1.6), head_r=[(0, -3), (45, -6), (N, -3)], face_p=[(0, FP(-6)), (45, FP(-10)), (N, FP(-6))]),
                [arc('L', 'down'), arc('R', 'down')], fx=[free_icon('sparkles', (660, 40), 140, 20, N, s=pulse_keys(N, 80, 105))])

N = 120
gl = [(0, (14, 18)), (50, (14, 18)), (60, (-14, 18)), (100, (-14, 18)), (110, (14, 18)), (N, (14, 18))]
EX['unimpressed'] = ub('Unimpressed', N, dict(breathe(N, 0.8), head_r=[(0, 1), (55, 1), (62, -2), (100, -2), (108, 1), (N, 1)],
                                              face_p=[(0, FP(6)), (55, FP(6)), (62, FP(-6)), (100, FP(-6)), (108, FP(6)), (N, FP(6))]), [
    lid('L', -6, 16), lid('R', -6, 16),
    pupil_group('L', {'p': offs(PUPIL_L, gl), 's': [100, 100], 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, gl), 's': [100, 100], 'o': 100})])

N = 60
def heart_eye(side):
    pc = PUPIL_L if side == 'L' else PUPIL_R
    beat = K([(0, [100, 100]), (8, [118, 118], 'out'), (16, [100, 100]), (24, [112, 112], 'out'), (32, [100, 100]), (N, [100, 100])])
    return gr([icon('red-heart', pc, 150)], 'heart-eye-' + side, a=pc, p=pc, s=beat)
hearts = []
for k, (x, y, sz, t0) in enumerate([(570, 40, 90, 0), (660, -30, 70, 20), (620, 10, 55, 40)]):
    p = K([(0, [x, y + 60], 'hold'), (t0, [x, y + 60], 'out'), (t0 + 40, [x + 20, y - 40]), (N, [x + 20, y - 40])])
    o = K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + 6, 100), (t0 + 30, 100, 'lin'), (t0 + 40, 0, 'hold'), (N, 0)])
    hearts.append(free_icon('red-heart', (x, y), sz, 20 + k, N, p=p, o=o, s=pop_keys(t0, None, N), r=K([(0, -10), (30, 10), (60, -10)])))
EX['in-love'] = ub('In Love', N, {'head_r': [(0, -4), (30, 4), (60, -4)], 'face_p': [(0, FP(-8)), (30, FP(8)), (60, FP(-8))],
                                  'root_p': [(0, P0), (30, up(10)), (60, P0)]}, [heart_eye('L'), heart_eye('R')], fx=hearts)

N = 60
cheer_L = [(0, 30), (8, 55), (15, 30), (23, 55), (30, 30), (38, 55), (45, 30), (53, 55), (60, 30)]
cheer_C = [(0, 0), (8, 30), (15, 0), (23, 30), (30, 0), (38, 30), (45, 0), (53, 30), (60, 0)]
EX['cheerful'] = ub('Cheerful', N, {
    'wingL': cheer_L, 'wingR': [(t, -v) for t, v in cheer_L],
    'wingL_curl': cheer_C, 'wingR_curl': [(t, -v) for t, v in cheer_C],
    'root_p': [(0, P0), (8, up(16), 'in'), (15, P0), (23, up(16), 'in'), (30, P0), (38, up(16), 'in'), (45, P0), (53, up(16), 'in'), (60, P0)],
    'head_r': [(0, -2), (30, 2), (60, -2)],
}, [arc('L', 'up', s=squish), arc('R', 'up', s=squish)], fx=[rays((660, 50), -50, [], 20, N, loop=True)])

# ---------------- use-case scenes ----------------
STAGE_S = ((375, 0), (335, 140), 66)
def sc(name, N, spec, face=None, fx=None, front=None):
    return build(name, N, spec, face=face, fx=fx, front=front, stage=STAGE_S)

SC = {}
# Onboarding: friendly wave
N = 72
wave_r, wave_c = [], []
for k in range(0, N + 1, 12):
    wave_r += [(k, -94), (k + 6, -108)] if k + 6 <= N else [(k, -94)]
    wave_c += [(k, 14), (k + 6, -24)] if k + 6 <= N else [(k, 14)]
sb, ab = blink([44], N)
SC['onboarding'] = sc('Onboarding', N, {
    'wingR': wave_r, 'wingR_curl': wave_c,
    'root_p': [(0, P0), (18, up(10)), (36, P0), (54, up(10)), (72, P0)],
    'head_r': [(0, -4), (36, -7), (72, -4)], 'face_p': [(0, FP(8)), (36, FP(12)), (72, FP(8))],
    'wingL_curl': [(0, 0), (36, 8), (72, 0)],
}, face=[arc('L', 'down', o=ab, w=16, dy=-10), arc('R', 'down', o=ab, w=16, dy=-10),
         pupil_group('L', {'p': offs(PUPIL_L, [(0, (6, -4))]) if False else [PUPIL_L[0] + 6, PUPIL_L[1] - 4], 's': sb, 'o': 100}),
         pupil_group('R', {'p': [PUPIL_R[0] + 6, PUPIL_R[1] - 4], 's': sb, 'o': 100})],
   fx=[free_icon('sparkles', (60, 40), 130, 20, N, s=pulse_keys(N, 80, 108)),
       free_icon('waving-hand' if False else 'sparkles', (840, 60), 90, 21, N, s=pulse_keys(N, 108, 80))])

# Empty state: holding an empty box, peeks in, then smiles
N = 120
look_e = [(0, (0, 30)), (30, (0, 30)), (38, (0, -4)), (100, (0, -4)), (108, (0, 30)), (N, (0, 30))]
happy_o = K([(0, 0, 'hold'), (50, 100, 'hold'), (84, 0, 'hold'), (N, 0)])
pup_o = K([(0, 100, 'hold'), (50, 0, 'hold'), (84, 100, 'hold'), (N, 100)])
box = layer('box', 30, [icon('package', (0, 0), 520)], a=(0, 0), p=K([(0, [375, 735]), (60, [375, 726]), (N, [375, 735])]),
            r=K([(0, -2), (60, 2), (N, -2)]), parent=1, N=N)
SC['empty-state'] = sc('Empty State', N, {
    'wingL': [(0, -18), (N, -18)], 'wingR': [(0, 18), (N, 18)],
    'wingL_curl': [(0, -38), (60, -44), (N, -38)], 'wingR_curl': [(0, 38), (60, 44), (N, 38)],
    'head_r': [(0, 0), (30, 0), (38, -4), (100, -4), (108, 0), (N, 0)],
    'head_p': [(0, [375, 484]), (30, [375, 484]), (38, [375, 470]), (100, [375, 470]), (108, [375, 484]), (N, [375, 484])],
    'face_p': [(0, FP(0)), (30, FP(0)), (38, FP(-8)), (100, FP(-8)), (108, FP(0)), (N, FP(0))],
    **breathe(N),
}, face=[arc('L', 'up', o=happy_o), arc('R', 'up', o=happy_o),
         pupil_group('L', {'p': offs(PUPIL_L, look_e), 's': [100, 100], 'o': pup_o}),
         pupil_group('R', {'p': offs(PUPIL_R, look_e), 's': [100, 100], 'o': pup_o})],
   front=[box], fx=[free_icon('sparkles', (640, 60), 110, 20, N, s=pop_keys(52, 84, N))])

# Feature discovery: looking through a telescope
N = 100
tele = layer('telescope', 31, [gr([icon('telescope', (0, 0), 470, recolor={r'<path fill="#7167a4"[^>]*/>': ''}, anchor=(29, 13.5))], 'flip', s=(-100, 100))],
             a=(0, 0), p=[535, 262], r=-4, parent=3, N=N)
SC['feature-discovery'] = sc('Feature Discovery', N, {
    'wingR': [(0, -62), (N, -62)], 'wingR_curl': [(0, -58), (50, -62), (N, -58)],
    'head_r': [(0, -5), (50, 4), (N, -5)],
    'face_p': [(0, FP(10)), (N, FP(10))],
    'fx_layers': [free_icon('sparkles', (930, -30), 130, 30, N, s=pop_keys(52, 90, N))],
    **breathe(N),
}, face=[arc('L', 'down'), pupil_group('R', {'p': [PUPIL_R[0] + 10, PUPIL_R[1] - 10], 's': [100, 100], 'o': 100})],
   fx=[tele])

# Success: holds up a glowing star
N = 90
SC['success'] = sc('Success', N, {
    'prop': {'kind': 'star', 'raise': -100, 'curl': -18, 'grip': 250, 'tilt': 0},
    'wingR': [(0, -100), (45, -106), (N, -100)], 'wingR_curl': [(0, -18), (45, -24), (N, -18)],
    'prop_s': [(0, [100, 100]), (22, [112, 112]), (45, [100, 100]), (67, [112, 112]), (N, [100, 100])],
    'prop_r': [(0, -8), (45, 8), (N, -8)],
    'wingL': [(0, 0), (45, 14), (N, 0)], 'wingL_curl': [(0, 0), (45, 20), (N, 0)],
    'root_p': [(0, P0), (22, up(14), 'in'), (45, P0), (67, up(14), 'in'), (N, P0)],
    'head_r': [(0, -3), (45, 3), (N, -3)], 'face_p': [(0, FP(4)), (45, FP(10)), (N, FP(4))],
}, face=[arc('L', 'up'), arc('R', 'up')],
   fx=[free_icon('sparkles', (920, 0), 120, 20, N, s=pulse_keys(N, 75, 110)),
       free_icon('sparkles', (40, 120), 90, 21, N, s=pulse_keys(N, 110, 75))])

# Error / no deals: puzzled, then a friendly shrug and smile
N = 120
look_q = [(0, (30, -34)), (40, (30, -34)), (48, (0, 0)), (N - 10, (0, 0)), (N, (30, -34))]
smile_o = K([(0, 0, 'hold'), (56, 100, 'hold'), (100, 0, 'hold'), (N, 0)])
eyes_o = K([(0, 100, 'hold'), (56, 0, 'hold'), (100, 100, 'hold'), (N, 100)])
brow_o = K([(0, 100, 'hold'), (46, 0, 'hold'), (104, 100, 'hold'), (N, 100)])
SC['error-no-deals'] = sc('Error / No Deals', N, {
    'wingL': [(0, 0), (44, 0, 'back'), (56, 34), (96, 34), (110, 0), (N, 0)],
    'wingR': [(0, 0), (44, 0, 'back'), (56, -34), (96, -34), (110, 0), (N, 0)],
    'wingL_curl': [(0, 0), (44, 0, 'back'), (56, 42), (96, 42), (110, 0), (N, 0)],
    'wingR_curl': [(0, 0), (44, 0, 'back'), (56, -42), (96, -42), (110, 0), (N, 0)],
    'head_r': [(0, 6), (40, 8), (52, -6), (96, -6), (110, 6), (N, 6)],
    'face_p': [(0, FP(12)), (40, FP(12)), (52, FP(-8)), (96, FP(-8)), (110, FP(12)), (N, FP(12))],
    'root_p': [(0, P0), (44, P0, 'out'), (52, up(16)), (60, P0), (N, P0)],
}, face=[brow('R', 'raised', o=brow_o), arc('L', 'up', o=smile_o), arc('R', 'up', o=smile_o),
         pupil_group('L', {'p': offs(PUPIL_L, look_q), 's': [100, 100], 'o': eyes_o}),
         pupil_group('R', {'p': offs(PUPIL_R, look_q), 's': [100, 100], 'o': eyes_o})],
   fx=[free_icon('red-question-mark', (690, -20), 170, 20, N, recolor=YELLOWIFY, r=K([(0, -10), (60, 10), (N, -10)]), s=pulse_keys(N, 95, 108))])

# Campaigns: megaphone announcement with confetti
N = 90
SC['campaigns'] = sc('Campaigns', N, {
    'prop': {'kind': 'megaphone', 'raise': -80, 'curl': -40, 'grip': 240, 'tilt': -6},
    'wingR': [(0, -80), (N, -80)], 'wingR_curl': [(0, -40), (N, -40)],
    'prop_s': [(0, [100, 100]), (6, [110, 110], 'out'), (14, [100, 100]), (36, [100, 100]), (42, [110, 110], 'out'), (50, [100, 100]), (N, [100, 100])],
    'prop_r': [(0, 0), (6, -6), (14, 0), (36, 0), (42, -6), (50, 0), (N, 0)],
    'wingL': [(0, 10), (45, 26), (N, 10)], 'wingL_curl': [(0, 10), (45, 26), (N, 10)],
    'root_p': [(0, P0), (6, up(12), 'out'), (14, P0), (36, P0), (42, up(12), 'out'), (50, P0), (N, P0)],
    'head_r': [(0, 3), (45, 5), (N, 3)], 'face_p': [(0, FP(10)), (N, FP(10))],
    'confetti': 4,
}, face=[pupil_group('L', {'p': [PUPIL_L[0] + 14, PUPIL_L[1] - 8], 's': [104, 104], 'o': 100}),
         pupil_group('R', {'p': [PUPIL_R[0] + 14, PUPIL_R[1] - 8], 's': [104, 104], 'o': 100})],
   fx=[free_icon('party-popper', (40, 60), 150, 20, N, s=pulse_keys(N, 90, 106), r=K([(0, -8), (45, 4), (N, -8)])),
       free_icon('sparkles', (700, -40), 120, 21, N, s=pulse_keys(N, 110, 80))])

ALL = {**{k: v for k, v in BODY.items()}, **{'expr-' + k: v for k, v in EX.items()}, **{'scene-' + k: v for k, v in SC.items()}}

if __name__ == '__main__':
    out = os.path.join(HERE, 'json')
    for f in os.listdir(out):
        os.remove(os.path.join(out, f))
    for k, v in ALL.items():
        fp = os.path.join(out, f'owl-{k}.json')
        json.dump(v, open(fp, 'w'), separators=(',', ':'))
        print(k, os.path.getsize(fp) // 1024, 'KB')
