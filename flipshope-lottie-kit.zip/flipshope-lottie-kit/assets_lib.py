"""Fluent Emoji (Flat) SVGs -> Lottie shape groups. Fluent Emoji is (c) Microsoft, MIT licensed."""
import json, os, re, copy
from lottie.parsers.svg import parse_svg_file
import io

HERE = os.path.dirname(os.path.abspath(__file__))
ICONS = json.load(open(os.path.join(HERE, 'node_modules/@iconify-json/fluent-emoji-flat/icons.json')))
_cache = {}

def svg_text(name, recolor=None):
    ic = ICONS['icons'][name]
    w, h = ic.get('width', ICONS.get('width', 32)), ic.get('height', ICONS.get('height', 32))
    body = ic['body']
    for a, b in (recolor or {}).items():
        body = re.sub(a, b, body, flags=re.I)
    return f'<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">{body}</svg>', w, h

def icon_shapes(name, recolor=None):
    """Returns (list of lottie shape items as dicts, width, height) for the icon in its own 0..w,0..h space."""
    key = (name, json.dumps(recolor or {}, sort_keys=True))
    if key in _cache:
        return copy.deepcopy(_cache[key])
    txt, w, h = svg_text(name, recolor)
    anim = parse_svg_file(io.StringIO(txt), 0, 60, 30)
    d = anim.to_dict()
    shapes = []
    for L in reversed(d['layers']):          # bottom first -> we will reverse to top-first at the end
        if L.get('ty') != 4:
            continue
        g = {"ty": "gr", "nm": L.get('nm', 'part'), "it": L['shapes'] + [_tr_from_ks(L['ks'])]}
        shapes.append(g)
    shapes = list(reversed(shapes))
    _cache[key] = (shapes, w, h)
    return copy.deepcopy((shapes, w, h))

def _tr_from_ks(ks):
    t = {"ty": "tr"}
    for k in ('a', 'p', 's', 'r', 'o'):
        if k in ks:
            t[k] = ks[k]
    t.setdefault('a', {"a": 0, "k": [0, 0]}); t.setdefault('p', {"a": 0, "k": [0, 0]})
    t.setdefault('s', {"a": 0, "k": [100, 100]}); t.setdefault('r', {"a": 0, "k": 0}); t.setdefault('o', {"a": 0, "k": 100})
    if isinstance(t['p'].get('k'), list) and len(t['p']['k']) == 3: t['p']['k'] = t['p']['k'][:2]
    if isinstance(t['a'].get('k'), list) and len(t['a']['k']) == 3: t['a']['k'] = t['a']['k'][:2]
    if isinstance(t['s'].get('k'), list) and len(t['s']['k']) == 3: t['s']['k'] = t['s']['k'][:2]
    return t

def icon(name, center, size, rot=0, recolor=None, nm=None, anchor=None):
    """A group drawing the icon scaled so its larger side equals `size`, centred on `center`.
    `anchor` (in icon units, default the icon centre) is the pivot placed at `center`."""
    shapes, w, h = icon_shapes(name, recolor)
    sc = size / max(w, h) * 100
    a = anchor or (w / 2, h / 2)
    tr = {"ty": "tr", "a": {"a": 0, "k": list(a)}, "p": {"a": 0, "k": list(center)}, "s": {"a": 0, "k": [sc, sc]},
          "r": {"a": 0, "k": rot}, "o": {"a": 0, "k": 100}}
    return {"ty": "gr", "nm": nm or name, "it": shapes + [tr]}
