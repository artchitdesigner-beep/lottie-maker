"""Build a single HTML preview page for Lottie files (publish it as an artifact or open locally).

    python3 board.py out/*.json -o out/preview.html --title "Diwali banners"
"""
import json, os, argparse, html

PAGE = """<title>{title}</title>
<meta name="claude:viewport-fit-sides" content="cover">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Baloo+2:wght@700;800&family=Figtree:wght@400;600&display=swap">
<style>
:root {{ --bg:#F3F6FF; --card:#fff; --ink:#0F1A3C; --muted:#5A6488; --line:#DCE3F7; --primary:#1E4DFF; }}
@media (prefers-color-scheme: dark) {{ :root:not([data-theme="light"]) {{ --bg:#0B1640; --card:#141F55; --ink:#EEF1FF; --muted:#A9B4E0; --line:#26347A; --primary:#7C96FF; color-scheme:dark }} }}
:root[data-theme="dark"] {{ --bg:#0B1640; --card:#141F55; --ink:#EEF1FF; --muted:#A9B4E0; --line:#26347A; --primary:#7C96FF; color-scheme:dark }}
body {{ background:var(--bg); color:var(--ink); font:15px/1.5 Figtree, system-ui, sans-serif; }}
.wrap {{ max-width:1200px; margin:0 auto; padding-block:28px 48px; padding-left:max(16px, env(safe-area-inset-left,0px)); padding-right:max(16px, env(safe-area-inset-right,0px)); }}
h1 {{ font:800 clamp(28px,4vw,40px)/1 "Baloo 2", system-ui, sans-serif; margin:0 0 6px; }}
.sub {{ color:var(--muted); margin:0 0 22px; }}
.grid {{ display:grid; grid-template-columns:repeat(auto-fill, minmax(300px, 1fr)); gap:18px; }}
.card {{ background:var(--card); border:1px solid var(--line); border-radius:18px; overflow:hidden; display:flex; flex-direction:column; min-width:0; }}
.stage {{ background-color:#fff; background-image:conic-gradient(#EEF1F8 25%, transparent 0 50%, #EEF1F8 0 75%, transparent 0); background-size:20px 20px; }}
.meta {{ padding:12px 14px; display:flex; justify-content:space-between; gap:10px; align-items:center; flex-wrap:wrap; }}
.meta b {{ font:700 17px "Baloo 2", system-ui, sans-serif; }}
.meta span {{ font-size:12.5px; color:var(--muted); font-variant-numeric:tabular-nums; }}
button {{ border:1px solid var(--line); background:var(--card); color:var(--ink); border-radius:10px; padding:6px 10px; font:600 13px Figtree, sans-serif; cursor:pointer; }}
button:hover {{ border-color:var(--primary); }}
button:focus-visible {{ outline:3px solid #FFC107; outline-offset:2px; }}
</style>
<div class="wrap"><h1>{title}</h1><p class="sub">{count} Lottie files in the Flipshope style. Click a preview to pause.</p><div class="grid" id="g"></div></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/lottie-web/5.12.2/lottie.min.js"></script>
<script>
const FILES = {data};
const g = document.getElementById('g');
FILES.forEach(f => {{
  const c = document.createElement('div'); c.className = 'card';
  c.innerHTML = `<div class="stage" style="aspect-ratio:${{f.d.w}}/${{f.d.h}}"></div><div class="meta"><div><b></b><br><span></span></div><button type="button">Copy JSON</button></div>`;
  c.querySelector('b').textContent = f.name;
  c.querySelector('span').textContent = `${{f.d.w}}×${{f.d.h}} · ${{(f.d.op / f.d.fr).toFixed(1)}}s · ${{f.kb}} KB`;
  g.appendChild(c);
  const a = lottie.loadAnimation({{ container: c.querySelector('.stage'), renderer: 'svg', loop: true, autoplay: true, animationData: f.d }});
  c.querySelector('.stage').onclick = () => a.isPaused ? a.play() : a.pause();
  const btn = c.querySelector('button');
  btn.onclick = () => navigator.clipboard.writeText(JSON.stringify(f.d)).then(() => btn.textContent = 'Copied', () => btn.textContent = 'Copy blocked');
}});
</script>
"""

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('files', nargs='+')
    ap.add_argument('-o', '--out', default='out/preview.html')
    ap.add_argument('--title', default='Flipshope animations')
    a = ap.parse_args()
    data = [{'name': os.path.splitext(os.path.basename(f))[0], 'kb': round(os.path.getsize(f) / 1024), 'd': json.load(open(f))}
            for f in a.files]
    page = PAGE.format(title=html.escape(a.title), count=len(data), data=json.dumps(data, separators=(',', ':')))
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    open(a.out, 'w').write(page)
    print(a.out)

if __name__ == '__main__':
    main()
