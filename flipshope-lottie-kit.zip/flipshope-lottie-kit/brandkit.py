"""Flipshope brand motion kit: build any Lottie (banner, motion poster, animated emoji, sticker, loader)
in the Flipshope style, with or without the owl.

    from brandkit import Scene, C
    s = Scene(1200, 400, frames=150, mode='cycle')
    s.background(gradient=(C['primary'], C['navy']), angle=90)
    s.text('Prices just dropped', 80, 150, size=72, color='white', anim='rise', t0=6)
    s.owl('face-deal-found', 1000, 200, size=300, anim='pop', t0=10)
    s.save('banner.json')

Everything is plain vector shapes (no text layers, no images, no expressions), so files play the same on
web, Android, iOS and React Native.
"""
import json, math, os, copy
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

from gen import K, st, sh, fl, sk, gr, tr, el, rc, hx, EASES
from assets_lib import icon as _icon

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------- tokens
C = {
    'primary': '#1E4DFF', 'owl': '#0148BD', 'accent': '#FFC107', 'cape': '#FFD402', 'beak': '#FFD92D',
    'surface': '#F3F6FF', 'card': '#FFFFFF', 'ink': '#0F1A3C', 'navy': '#0B1640', 'muted': '#5A6488',
    'line': '#DCE3F7', 'white': '#FFFFFF', 'green': '#1F9D55', 'red': '#E5383B', 'mint': '#E8F7EE',
    'peach': '#FFF4DE', 'lilac': '#F1EEFF', 'sky': '#E3E9FF', 'purple': '#9B5CF6', 'pink': '#FF5FA2',
}
CONFETTI = ['#9B5CF6', '#FFC107', '#2F6BFF', '#FF5FA2', '#22C55E']
DUR = {'xs': 6, 'sm': 10, 'md': 16, 'lg': 24}          # frames at 30 fps

def col(c, a=1):
    """Colour token name or hex -> lottie rgba list."""
    return hx(C.get(c, c), a)

# ---------------------------------------------------------------- fonts -> shapes
FONTS = {
    'display': ('baloo-2', 'baloo-2-{sub}-{w}-normal.woff2', 800),
    'body': ('figtree', 'figtree-{sub}-{w}-normal.woff2', 600),
}
_font_cache = {}

def _fonts(kind, weight):
    pkg, pat, default_w = FONTS[kind]
    w = weight or default_w
    key = (kind, w)
    if key not in _font_cache:
        out = []
        for sub in ('latin', 'latin-ext', 'devanagari', 'vietnamese'):
            p = os.path.join(HERE, 'node_modules/@fontsource', pkg, 'files', pat.format(sub=sub, w=w))
            if os.path.exists(p):
                f = TTFont(p)
                out.append((f, f.getGlyphSet(), f.getBestCmap(), f['hmtx']))
        if not out:
            raise FileNotFoundError(f'No font files for {kind} {w}. Run setup.sh first.')
        _font_cache[key] = out
    return _font_cache[key]

class _LottiePen(BasePen):
    def __init__(self, gs, s, ox, oy):
        super().__init__(gs)
        self.s, self.ox, self.oy = s, ox, oy
        self.paths, self.cur = [], None
    def _p(self, pt):
        return [int(round(self.ox + pt[0] * self.s)), int(round(self.oy - pt[1] * self.s))]
    def _moveTo(self, pt):
        self.cur = {'v': [self._p(pt)], 'i': [[0, 0]], 'o': [[0, 0]]}
    def _lineTo(self, pt):
        self.cur['v'].append(self._p(pt)); self.cur['i'].append([0, 0]); self.cur['o'].append([0, 0])
    def _curveToOne(self, p1, p2, p3):
        a, b, c = self._p(p1), self._p(p2), self._p(p3)
        last = self.cur['v'][-1]
        self.cur['o'][-1] = [a[0] - last[0], a[1] - last[1]]
        self.cur['v'].append(c); self.cur['i'].append([b[0] - c[0], b[1] - c[1]]); self.cur['o'].append([0, 0])
    def _qCurveToOne(self, p1, p2):
        p0 = self._getCurrentPoint()
        c1 = (p0[0] + 2 / 3 * (p1[0] - p0[0]), p0[1] + 2 / 3 * (p1[1] - p0[1]))
        c2 = (p2[0] + 2 / 3 * (p1[0] - p2[0]), p2[1] + 2 / 3 * (p1[1] - p2[1]))
        self._curveToOne(c1, c2, p2)
    def _closePath(self):
        c = self.cur
        if len(c['v']) > 1 and abs(c['v'][0][0] - c['v'][-1][0]) < .01 and abs(c['v'][0][1] - c['v'][-1][1]) < .01:
            c['i'][0] = c['i'][-1]; c['v'].pop(); c['i'].pop(); c['o'].pop()
        c['c'] = True
        self.paths.append(c); self.cur = None
    _endPath = _closePath

def _glyph(fonts, ch):
    for f, gs, cmap, hmtx in fonts:
        if ord(ch) in cmap:
            g = cmap[ord(ch)]
            return f, gs, g, hmtx[g][0]
    f, gs, cmap, hmtx = fonts[0]
    return f, gs, '.notdef', hmtx['.notdef'][0] if '.notdef' in hmtx.metrics else 500

def measure(text, size, font='display', weight=None, tracking=0):
    fonts = _fonts(font, weight)
    upm = fonts[0][0]['head'].unitsPerEm
    s = size / upm
    return sum(_glyph(fonts, ch)[3] * s + tracking for ch in text) - (tracking if text else 0)

def wrap(text, size, max_width, font='display', weight=None, tracking=0):
    lines = []
    for para in text.split('\n'):
        cur = ''
        for word in para.split(' '):
            trial = (cur + ' ' + word).strip()
            if cur and measure(trial, size, font, weight, tracking) > max_width:
                lines.append(cur); cur = word
            else:
                cur = trial
        lines.append(cur)
    return lines

def text_paths(text, x, y, size, font='display', weight=None, align='left', tracking=0, line_height=1.05,
               max_width=None, split=None):
    """Vector outlines for text. (x, y) is the top-left (align left), top-centre (center) or top-right (right)
    of the block. Returns (groups, width, height). split='words' or 'lines' returns one group per piece,
    each with its own transform so it can be animated separately; otherwise one group."""
    fonts = _fonts(font, weight)
    upm = fonts[0][0]['head'].unitsPerEm
    s = size / upm
    asc = fonts[0][0]['hhea'].ascent * s
    lines = wrap(text, size, max_width, font, weight, tracking) if max_width else text.split('\n')
    lh = size * line_height
    pieces, maxw = [], 0
    for li, line in enumerate(lines):
        w = measure(line, size, font, weight, tracking)
        maxw = max(maxw, w)
        ox = x if align == 'left' else (x - w / 2 if align == 'center' else x - w)
        base = y + asc * 0.82 + li * lh
        word_paths, cur_word, pen_x = [], [], ox
        for ch in line:
            f, gs, g, adv = _glyph(fonts, ch)
            if ch == ' ':
                if cur_word: word_paths.append(cur_word); cur_word = []
            else:
                pen = _LottiePen(gs, s, pen_x, base)
                gs[g].draw(pen)
                cur_word += pen.paths
            pen_x += adv * s + tracking
        if cur_word: word_paths.append(cur_word)
        if split == 'words':
            pieces += [(wp, li) for wp in word_paths]
        else:
            pieces.append(([p for wp in word_paths for p in wp], li))
    height = lh * (len(lines) - 1) + size
    if split in ('words', 'lines'):
        return [[{"ty": "sh", "d": 1, "nm": "glyphs", "ks": st(p)} for p in ps] for ps, _ in pieces], maxw, height
    allp = [p for ps, _ in pieces for p in ps]
    return [[{"ty": "sh", "d": 1, "nm": "glyphs", "ks": st(p)} for p in allp]], maxw, height

# ---------------------------------------------------------------- helpers
def grad_fill(c1, c2, start, end, kind='linear', a1=1, a2=1):
    c1, c2 = col(c1), col(c2)
    g = {"ty": "gf", "nm": "gradient", "o": st(100), "r": 1, "t": 1 if kind == 'linear' else 2,
         "s": st(list(start)), "e": st(list(end)),
         "g": {"p": 2, "k": st([0, *c1[:3], 1, *c2[:3], 0, a1, 1, a2])}}
    if kind != 'linear':
        g["h"] = st(0); g["a"] = st(0)
    return g

def rrect(x, y, w, h, r):
    return {"ty": "rc", "p": st([x + w / 2, y + h / 2]), "s": st([w, h]), "r": st(r), "d": 1, "nm": "rect"}

def ellipse(cx, cy, rx, ry=None):
    return el((cx, cy), (rx * 2, (ry or rx) * 2))

def star_path(cx, cy, R, points=4, inner=0.32, rot=-90):
    v = []
    for k in range(points * 2):
        r = R if k % 2 == 0 else R * inner
        a = math.radians(rot + k * 180 / points)
        v.append([round(cx + r * math.cos(a), 2), round(cy + r * math.sin(a), 2)])
    return sh(v)

def _ks(a=(0, 0), p=(0, 0), s=(100, 100), r=0, o=100):
    v = lambda x: x if isinstance(x, dict) else st(list(x) if isinstance(x, (list, tuple)) else x)
    return {"a": v(a), "p": v(p), "s": v(s), "r": v(r), "o": v(o)}

# ---------------------------------------------------------------- motion presets
def entrance(kind, t0, pos, d=None, dist=60):
    """Keyframes for an entrance. Returns dict of transform props (p, s, r, o) to merge into a layer."""
    d = d or DUR['md']
    x, y = pos
    hold = lambda v: (t0, v, 'hold')
    if kind == 'pop':
        return {'s': K([(0, [0, 0], 'hold'), (t0, [0, 0], 'back'), (t0 + d, [100, 100])]),
                'o': K([(0, 0, 'hold'), (t0, 100)])}
    if kind == 'rise':
        return {'p': K([(0, [x, y + dist], 'hold'), (t0, [x, y + dist], 'out'), (t0 + d, [x, y])]),
                'o': K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + d * 0.6, 100)])}
    if kind == 'drop':
        return {'p': K([(0, [x, y - dist * 1.5], 'hold'), (t0, [x, y - dist * 1.5], 'back'), (t0 + d, [x, y])]),
                'o': K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + 4, 100)])}
    if kind in ('slide-left', 'slide-right'):
        dx = dist * 2 * (1 if kind == 'slide-left' else -1)
        return {'p': K([(0, [x + dx, y], 'hold'), (t0, [x + dx, y], 'out'), (t0 + d, [x, y])]),
                'o': K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + d * 0.6, 100)])}
    if kind == 'fade':
        return {'o': K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + d, 100)])}
    if kind == 'stamp':
        return {'s': K([(0, [0, 0], 'hold'), (t0, [180, 180], 'in'), (t0 + d * 0.6, [92, 92], 'out'), (t0 + d, [100, 100])]),
                'o': K([(0, 0, 'hold'), (t0, 0, 'lin'), (t0 + 3, 100)]),
                'r': K([(0, -12, 'hold'), (t0, -12, 'out'), (t0 + d, 0)])}
    if kind == 'spin-in':
        return {'s': K([(0, [0, 0], 'hold'), (t0, [0, 0], 'back'), (t0 + d, [100, 100])]),
                'r': K([(0, -180, 'hold'), (t0, -180, 'out'), (t0 + d, 0)]), 'o': K([(0, 0, 'hold'), (t0, 100)])}
    raise ValueError(kind)

def idle(kind, N, amp=None, phase=0, period=None):
    """Seamless loop keyframes (start == end) for an inner group transform."""
    P = period or N
    reps = max(1, round(N / P))
    P = N / reps
    def keys(vals):
        out = []
        for r in range(reps):
            for k, v in enumerate(vals):
                out.append((round(r * P + k * P / (len(vals))), v))
        out.append((N, vals[0]))
        return K(out)
    if kind == 'float':
        a = amp or 10
        return {'p': keys([[0, 0], [0, -a], [0, 0], [0, a * 0.4]])}
    if kind == 'pulse':
        a = amp or 6
        return {'s': keys([[100, 100], [100 + a, 100 + a]])}
    if kind == 'wiggle':
        a = amp or 6
        return {'r': keys([0, a, 0, -a])}
    if kind == 'spin':
        return {'r': K([(0, 0, 'lin'), (N, 360 * (amp or 1))])}
    if kind == 'breathe':
        a = amp or 2
        return {'s': keys([[100, 100], [100 + a * 0.5, 100 - a * 0.5]])}
    if kind == 'swing':
        a = amp or 10
        return {'r': keys([a, -a])}
    raise ValueError(kind)

def exit_keys(kind, t1, d, base):
    """Fade/scale out ending at t1, used by mode='cycle' so the loop restarts cleanly."""
    return {'o': K([(0, 100), (t1 - d, 100, 'in'), (t1, 0)])}

# ---------------------------------------------------------------- scene
class Scene:
    """A Lottie composition built from brand pieces.

    mode: 'loop'  every element only idles; first frame == last frame (emoji, stickers, loaders).
          'once'  entrances, then everything holds/idles. Play once, or loop from a marker.
          'cycle' entrances, idle, then everything fades out at the end so the file loops cleanly (banners).
    """
    def __init__(self, w, h, frames=120, fps=30, name='Flipshope', mode='cycle', exit_frames=10):
        self.w, self.h, self.N, self.fps, self.name, self.mode = w, h, frames, fps, name, mode
        self.exit = exit_frames
        self._layers, self._assets, self._ind = [], [], 1

    # -- low level
    def add_layer(self, nm, shapes, anchor=(0, 0), pos=None, scale=(100, 100), rot=0, opacity=100,
                  anim=None, t0=0, d=None, loop=None, loop_amp=None, loop_period=None, exit=True):
        """Add a shape layer. `shapes` are drawn in canvas coordinates. anim: entrance preset;
        loop: idle preset applied to an inner group so it combines with the entrance."""
        pos = tuple(pos) if pos is not None else tuple(anchor)
        t = {"ty": "tr", **_ks(a=anchor, p=anchor)}
        if loop:
            inner = idle(loop, self.N, loop_amp, period=loop_period)
            if 'p' in inner:   # offsets -> absolute around the anchor
                for kf in inner['p']['k']:
                    kf['s'] = [anchor[0] + kf['s'][0], anchor[1] + kf['s'][1]]
            t.update(inner)
        g = {"ty": "gr", "nm": nm + '-content', "it": list(shapes) + [t]}
        ks = _ks(a=anchor, p=pos, s=scale, r=rot, o=opacity)
        if anim:
            ks.update(entrance(anim, t0, pos, d))
        if self.mode == 'cycle' and exit:
            ks['o'] = self._with_exit(ks['o'])
        L = {"ddd": 0, "ind": self._ind, "ty": 4, "nm": nm, "sr": 1, "ao": 0, "bm": 0, "ks": ks,
             "shapes": [g], "ip": 0, "op": self.N, "st": 0}
        self._ind += 1
        self._layers.insert(0, L)
        return L

    def _with_exit(self, o):
        t1 = self.N - 1
        ta = t1 - self.exit
        if o.get('a') == 0:
            return K([(0, o['k']), (ta, o['k'], 'in'), (t1, 0)])
        ks = [k for k in o['k'] if k['t'] < ta]
        last = ks[-1]['s'][0] if ks else 100
        ks = copy.deepcopy(ks)
        for k in ks:
            if 'h' not in k and 'o' not in k:
                k['o'] = {"x": [0.45], "y": [0]}; k['i'] = {"x": [0.55], "y": [1]}
        ks.append({"t": ta, "s": [last], "o": {"x": [0.6], "y": [0]}, "i": {"x": [0.85], "y": [0.4]}})
        ks.append({"t": t1, "s": [0]})
        return {"a": 1, "k": ks}

    # -- building blocks
    def background(self, color='surface', gradient=None, angle=90, radius=0):
        if gradient:
            a = math.radians(angle)
            cx, cy, R = self.w / 2, self.h / 2, max(self.w, self.h) / 2
            s = (cx - R * math.cos(a), cy - R * math.sin(a)); e = (cx + R * math.cos(a), cy + R * math.sin(a))
            fill = grad_fill(gradient[0], gradient[1], s, e)
        else:
            fill = fl(col(color))
        L = self.add_layer('background', [rrect(0, 0, self.w, self.h, radius), fill], exit=False)
        self._layers.remove(L); self._layers.append(L)       # always at the bottom
        return L

    def glow(self, cx, cy, r, color='accent', alpha=0.35, **kw):
        """Soft radial glow (brand lighting). Use behind the hero element."""
        kw.setdefault('exit', False)
        return self.add_layer('glow', [ellipse(cx, cy, r), grad_fill(color, color, (cx, cy), (cx + r, cy), 'radial', alpha, 0)],
                              anchor=(cx, cy), **kw)

    def blob(self, cx, cy, r, color='sky', alpha=1, **kw):
        kw.setdefault('exit', False)
        return self.add_layer('blob', [ellipse(cx, cy, r), fl(col(color), alpha * 100)], anchor=(cx, cy), **kw)

    def card(self, x, y, w, h, radius=28, color='card', shadow=True, border=None, **kw):
        items = []
        if border:
            items.append(sk(col(border), 2))
        shapes = [rrect(x, y, w, h, radius)] + items + [fl(col(color))]
        if shadow:
            sh_ = [gr([rrect(x + 4, y + 14, w - 8, h, radius), fl(col('ink'), 8)], 'shadow-far'),
                   gr([rrect(x + 2, y + 5, w - 4, h, radius), fl(col('ink'), 6)], 'shadow-near')]
            shapes = [gr(shapes, 'card')] + sh_
        return self.add_layer('card', shapes, anchor=(x + w / 2, y + h / 2), **kw)

    def text(self, text, x, y, size=64, color='ink', font='display', weight=None, align='left', max_width=None,
             tracking=0, line_height=1.05, anim=None, t0=0, stagger=0, d=None, loop=None, **kw):
        """Text as vector shapes. stagger>0 animates word by word (frames between words)."""
        if stagger and anim:
            groups, w, h = text_paths(text, x, y, size, font, weight, align, tracking, line_height, max_width, split='words')
            items = []
            for k, g in enumerate(groups):
                ta = t0 + k * stagger
                xs = [p for s_ in g for p in s_['ks']['k']['v']]
                gx = (min(v[0] for v in xs) + max(v[0] for v in xs)) / 2 if xs else x
                gy = (min(v[1] for v in xs) + max(v[1] for v in xs)) / 2 if xs else y
                e = entrance(anim, ta, (gx, gy), d)
                t_ = {"ty": "tr", **_ks(a=(gx, gy), p=(gx, gy))}
                t_.update(e)
                items.append({"ty": "gr", "nm": "word", "it": g + [fl(col(color)), t_]})
            return self.add_layer('text', list(reversed(items)), anchor=(x, y), loop=loop, **kw), w, h
        groups, w, h = text_paths(text, x, y, size, font, weight, align, tracking, line_height, max_width)
        ax = x + w / 2 if align == 'left' else (x if align == 'center' else x - w / 2)
        L = self.add_layer('text', [{"ty": "gr", "nm": "glyphs", "it": groups[0] + [fl(col(color)), {"ty": "tr", **_ks()}]}],
                           anchor=(ax, y + h / 2),
                           anim=anim, t0=t0, d=d, loop=loop, **kw)
        return L, w, h

    def pill(self, text, x, y, size=26, color='primary', text_color='white', font='body', weight=700, pad=(22, 12),
             align='left', **kw):
        w = measure(text, size, font, weight) + pad[0] * 2
        h = size * 1.2 + pad[1] * 2
        x0 = x if align == 'left' else (x - w / 2 if align == 'center' else x - w)
        groups, _, _ = text_paths(text, x0 + pad[0], y + pad[1] + size * 0.05, size, font, weight)
        shapes = [gr(groups[0] + [fl(col(text_color))], 'label'), gr([rrect(x0, y, w, h, h / 2), fl(col(color))], 'bg')]
        return self.add_layer('pill', shapes, anchor=(x0 + w / 2, y + h / 2), **kw), w, h

    def button(self, text, x, y, size=30, color='primary', text_color='white', **kw):
        return self.pill(text, x, y, size, color, text_color, 'body', 700, pad=(34, 18), **kw)

    def icon(self, name, cx, cy, size, recolor=None, **kw):
        """Fluent Emoji (flat, MIT) icon by name, e.g. 'bell', 'fire', 'party-popper', 'shopping-bags'."""
        return self.add_layer(name, [_icon(name, (cx, cy), size, recolor=recolor)], anchor=(cx, cy), **kw)

    def sparkle(self, cx, cy, R=30, color='accent', **kw):
        return self.add_layer('sparkle', [gr([star_path(cx, cy, R), fl(col(color))], 'star')], anchor=(cx, cy), **kw)

    def rays(self, cx, cy, angle=-50, size=1.0, color='accent', t0=0, **kw):
        """Three short burst lines (the brand 'ping'), pointing at `angle` degrees."""
        items = []
        for d in (-38, 0, 38):
            a = math.radians(angle + d)
            r1, r2 = 22 * size, 58 * size
            items.append(sh([[cx + r1 * math.cos(a), cy + r1 * math.sin(a)], [cx + r2 * math.cos(a), cy + r2 * math.sin(a)]], closed=False))
        return self.add_layer('rays', [gr(items + [sk(col(color), 12 * size)], 'rays')], anchor=(cx, cy),
                              anim=kw.pop('anim', 'pop'), t0=t0, **kw)

    def confetti(self, cx, cy, t0=0, count=18, spread=1.0, colors=CONFETTI):
        for k in range(count):
            ang = -170 + k * (160 / max(count - 1, 1)) + (7 if k % 2 else -5)
            dist = (220 + (k * 53 % 120)) * spread
            a = math.radians(ang)
            tx, ty = cx + dist * math.cos(a), cy + dist * math.sin(a)
            w, h = (14, 26) if k % 3 else (17, 17)
            s0 = t0 + (k % 4)
            ks = _ks(a=(0, 0))
            ks['p'] = K([(0, [cx, cy], 'hold'), (s0, [cx, cy], 'out'), (s0 + 18, [tx, ty], 'in'),
                         (s0 + 40, [tx + 10 * math.cos(a), ty + 70], 'lin'), (self.N, [tx + 10 * math.cos(a), ty + 70])])
            ks['r'] = K([(s0, 0, 'lin'), (s0 + 40, 540 * (1 if k % 2 else -1))])
            ks['o'] = K([(0, 0, 'hold'), (s0, 100, 'hold'), (s0 + 28, 100, 'lin'), (s0 + 40, 0, 'hold'), (self.N, 0)])
            ks['s'] = K([(0, [0, 0], 'hold'), (s0, [40, 40], 'out'), (s0 + 8, [100, 100]), (self.N, [100, 100])])
            L = {"ddd": 0, "ind": self._ind, "ty": 4, "nm": "confetti", "sr": 1, "ao": 0, "bm": 0, "ks": ks,
                 "shapes": [gr([rrect(-w / 2, -h / 2, w, h, 4), fl(col(colors[k % len(colors)]))], 'piece')],
                 "ip": 0, "op": self.N, "st": 0}
            self._ind += 1
            self._layers.insert(0, L)

    def owl(self, which, cx, cy, size, anim=None, t0=0, d=None, loop=True, flip=False, **kw):
        """Place an owl animation (key from the library, e.g. 'face-deal-found', 'expr-happy', 'celebrate',
        'scene-campaigns', or a lottie dict) centred at (cx, cy), `size` px wide. Loops inside the scene."""
        data = which if isinstance(which, dict) else owl_library()[which]
        data = copy.deepcopy(data)
        rid = f'owl_{len(self._assets)}'
        self._assets.append({"id": rid, "nm": data.get('nm', rid), "fr": data['fr'], "layers": data['layers']})
        cw, ch, cn = data['w'], data['h'], data['op']
        if self.mode == 'loop' and self.N % cn:
            print(f"warning: owl clip is {cn} frames but the scene is {self.N}; use frames={cn} or a multiple for a seamless loop")
        sc = size / cw * 100
        ks = _ks(a=(cw / 2, ch / 2), p=(cx, cy), s=(-sc if flip else sc, sc))
        if anim:
            e = entrance(anim, t0, (cx, cy), d)
            if 's' in e:
                for kf in e['s']['k']:
                    kf['s'] = [kf['s'][0] * sc / 100 * (-1 if flip else 1), kf['s'][1] * sc / 100]
            ks.update(e)
        if self.mode == 'cycle':
            ks['o'] = self._with_exit(ks['o'])
        L = {"ddd": 0, "ind": self._ind, "ty": 0, "nm": "owl", "refId": rid, "sr": 1, "ao": 0, "bm": 0, "ks": ks,
             "w": cw, "h": ch, "ip": 0, "op": self.N, "st": 0}
        if loop and cn < self.N:
            keys, f = [], 0
            while f < self.N:
                keys.append({"t": f, "s": [0], "o": {"x": [0], "y": [0]}, "i": {"x": [1], "y": [1]}})
                keys.append({"t": f + cn - 1, "s": [(cn - 1) / data['fr']], "h": 1})
                f += cn
            keys.append({"t": f, "s": [0]})
            L["tm"] = {"a": 1, "k": keys}
        self._ind += 1
        self._layers.insert(0, L)
        return L

    # -- output
    def to_dict(self):
        return {"v": "5.12.2", "fr": self.fps, "ip": 0, "op": self.N, "w": self.w, "h": self.h, "nm": self.name,
                "ddd": 0, "assets": self._assets, "layers": self._layers, "markers": []}

    def save(self, path):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, 'w') as f:
            json.dump(self.to_dict(), f, separators=(',', ':'))
        return path

_LIB = None
def owl_library():
    """All 27 owl animations by key: idle-blink, walking, search-analyze, price-alert, celebrate,
    expr-* (10), scene-* (6), face-* (6)."""
    global _LIB
    if _LIB is None:
        import anims5, faces6
        _LIB = dict(anims5.ALL)
        _LIB.update({'face-' + k: v for k, v in faces6.F.items()})
    return _LIB
