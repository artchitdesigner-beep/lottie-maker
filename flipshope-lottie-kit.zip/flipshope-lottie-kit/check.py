"""Validate and preview Lottie files.

    python3 check.py out/banner.json [more.json ...] [--frames 8] [--bg "#F3F6FF"]

For each file: plays it in lottie-web (headless Chromium), reports errors, size, duration, features that
mobile players don't support, whether it loops seamlessly, and writes <name>.sheet.png (frame strip)
and <name>.png (a large still at 40%).
"""
import json, os, sys, argparse

HERE = os.path.dirname(os.path.abspath(__file__))
LIB = os.path.join(HERE, 'node_modules/lottie-web/build/player/lottie.min.js')

def scan(node, found):
    if isinstance(node, dict):
        if node.get('ty') == 5: found.add('text layer (needs fonts on device; use Scene.text instead)')
        if node.get('ty') == 2: found.add('image layer (not vector)')
        if 'ef' in node and node['ef']: found.add('effects (unsupported on mobile)')
        if node.get('ty') == 'mm': found.add('merge paths (not on iOS/web)')
        for k, v in node.items():
            if k in ('x',) and isinstance(v, str): found.add('expressions (unsupported on mobile)')
            scan(v, found)
    elif isinstance(node, list):
        for v in node: scan(v, found)

def launch(p):
    try:
        return p.chromium.launch()
    except Exception:
        return p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--no-sandbox', '--headless=new'])

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('files', nargs='+')
    ap.add_argument('--frames', type=int, default=8)
    ap.add_argument('--bg', default='#F3F6FF')
    a = ap.parse_args()
    from playwright.sync_api import sync_playwright
    lib = open(LIB).read()
    ok_all = True
    with sync_playwright() as p:
        b = launch(p)
        for f in a.files:
            d = json.load(open(f))
            w, h, op, fr = d['w'], d['h'], d['op'] - d.get('ip', 0), d['fr']
            issues = set(); scan(d, issues)
            cell = 220
            cw = cell; ch = round(cell * h / w)
            pg = b.new_page(viewport={'width': cw * a.frames, 'height': ch})
            errs = []
            pg.on('pageerror', lambda e: errs.append(str(e)))
            frames = [round(op * k / a.frames) for k in range(a.frames)]
            pg.set_content(f'<html><body style="margin:0;display:flex;background:{a.bg}">' +
                           ''.join(f'<div id=c{k} style="width:{cw}px;height:{ch}px;flex:none"></div>' for k in range(a.frames)) +
                           f'<script>{lib}</script></body></html>')
            res = pg.evaluate("""([d, fr]) => fr.map((f, k) => { try { const an = lottie.loadAnimation({container: document.getElementById('c'+k),
                renderer: 'svg', loop: false, autoplay: false, animationData: JSON.parse(JSON.stringify(d))}); an.goToAndStop(f, true); return null }
                catch (e) { return String(e) } }).filter(Boolean)""", [d, frames])
            errs += res
            pg.wait_for_timeout(150)
            base = os.path.splitext(f)[0]
            pg.screenshot(path=base + '.sheet.png')
            # loop seam: compare first and last frame
            big = b.new_page(viewport={'width': 400, 'height': round(400 * h / w)})
            big.set_content(f'<html><body style="margin:0;background:{a.bg}"><div id=c style="width:400px;height:{round(400*h/w)}px"></div><script>{lib}</script></body></html>')
            big.evaluate("(d) => { window.A = lottie.loadAnimation({container: document.getElementById('c'), renderer: 'svg', loop: false, autoplay: false, animationData: d}) }", d)
            big.evaluate(f"A.goToAndStop(0, true)"); s0 = big.screenshot()
            big.evaluate(f"A.goToAndStop({op - 1}, true)"); s1 = big.screenshot()
            from PIL import Image, ImageChops
            import io
            im0, im1 = Image.open(io.BytesIO(s0)).convert('RGB'), Image.open(io.BytesIO(s1)).convert('RGB')
            diff = ImageChops.difference(im0, im1).convert('L')
            changed = sum(1 for v in diff.tobytes() if v > 24) / (im0.width * im0.height)
            seam = 'seamless' if changed < 0.01 else f'jumps at the loop point ({changed:.0%} of pixels change)'
            hero = b.new_page(viewport={'width': min(w, 1200), 'height': round(min(w, 1200) * h / w)})
            hero.set_content(f'<html><body style="margin:0;background:{a.bg}"><div id=c style="width:100%;height:100vh"></div><script>{lib}</script></body></html>')
            hero.evaluate(f"(d) => {{ const an = lottie.loadAnimation({{container: document.getElementById('c'), renderer: 'svg', loop: false, autoplay: false, animationData: d}}); an.goToAndStop({round(op*0.4)}, true) }}", d)
            hero.screenshot(path=base + '.png')
            for x in (pg, big, hero): x.close()
            kb = os.path.getsize(f) / 1024
            ok = not errs
            ok_all &= ok
            print(f"{'OK ' if ok else 'ERR'} {os.path.basename(f)}  {w}x{h}  {op} frames ({op/fr:.2f}s @ {fr}fps)  {kb:.0f} KB  loop: {seam}")
            for e in errs[:3]: print('    error:', e)
            for i in sorted(issues): print('    warning:', i)
            budget = 60 if max(w, h) <= 512 else (150 if w * h <= 1200 * 630 else 250)
            if kb > budget: print(f'    warning: over the {budget} KB budget for this size; simplify shapes, shorten, or drop the full-body owl for a face')
            print(f'    preview: {base}.sheet.png  {base}.png')
        b.close()
    sys.exit(0 if ok_all else 1)

if __name__ == '__main__':
    main()
