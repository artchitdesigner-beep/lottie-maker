"""Web banner 1200x400: headline, price pill, CTA, owl face, confetti. mode='cycle' so it loops cleanly."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from brandkit import Scene

s = Scene(1200, 400, frames=150, mode='cycle', name='Banner · Price drop')
s.background(gradient=('primary', 'navy'), angle=0)
s.glow(980, 210, 260, 'accent', 0.35)
s.blob(1130, 40, 90, 'white', 0.06, loop='float', loop_amp=8)
s.blob(860, 380, 60, 'white', 0.06, loop='float', loop_amp=6, loop_period=75)
s.pill('PRICE DROP ALERT', 80, 70, size=20, color='accent', text_color='ink', anim='pop', t0=4)
s.text('Prices just dropped\non your wishlist', 80, 124, size=62, color='white', anim='rise', t0=8, stagger=3, line_height=1.0)
s.text('Up to 40% off on 120+ tracked products', 80, 268, size=24, color='#C9D2F7', font='body', weight=500, anim='fade', t0=26)
s.button('See my deals', 80, 316, size=22, color='white', text_color='primary', anim='pop', t0=34)
s.owl('face-deal-found', 990, 215, size=360, anim='pop', t0=12)
s.rays(1105, 95, angle=-40, t0=24, size=0.9)
s.confetti(990, 140, t0=20, count=14, spread=0.9)
s.save('out/banner-price-drop.json')
