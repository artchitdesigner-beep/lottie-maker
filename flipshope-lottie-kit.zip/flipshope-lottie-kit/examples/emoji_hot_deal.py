"""Animated emoji / sticker 512x512, seamless loop (mode='loop'): fire + owl face + 'HOT' stamp."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from brandkit import Scene

s = Scene(512, 512, frames=72, mode='loop', name='Emoji · Hot deal')
s.icon('fire', 256, 230, 330, loop='pulse', loop_amp=5, loop_period=36)
s.owl('face-alert', 256, 300, size=300)
s.pill('HOT DEAL', 256, 410, size=34, color='red', text_color='white', align='center', loop='wiggle', loop_amp=4)
s.save('out/emoji-hot-deal.json')
