"""Motion poster 1080x1350 (Instagram portrait): owl celebrate, headline, offer card, CTA."""
import sys, os; sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from brandkit import Scene

s = Scene(1080, 1350, frames=180, mode='cycle', name='Poster · Weekend sale')
s.background(gradient=('#2A55FF', 'navy'), angle=90)
s.glow(540, 520, 420, 'accent', 0.3)
s.sparkle(160, 200, 26, loop='pulse', loop_amp=20, loop_period=45)
s.sparkle(930, 320, 18, loop='pulse', loop_amp=25, loop_period=60)
s.pill('FLIPSHOPE WEEKEND SALE', 540, 90, size=26, color='accent', text_color='ink', align='center', anim='drop', t0=4)
s.text('Track it.\nCatch the drop.', 540, 170, size=110, color='white', align='center', anim='rise', t0=10, stagger=4, line_height=0.95)
s.owl('celebrate', 540, 720, size=720, anim='pop', t0=16)
s.card(140, 1010, 800, 150, radius=36, anim='rise', t0=34)
s.text('Price history  ·  Alerts  ·  Compare', 540, 1036, size=30, color='muted', font='body', weight=600, align='center', anim='fade', t0=40)
s.text('Never overpay again', 540, 1082, size=52, color='primary', align='center', anim='fade', t0=44)
s.button('Install the free extension', 540, 1212, size=32, color='accent', text_color='ink', align='center', anim='pop', t0=52)
s.save('out/poster-weekend-sale.json')
