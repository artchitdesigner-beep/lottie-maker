"""Upper-body expression loops (head + collar + wings + cape top), built on the v4 rig."""
import json, math, os
from gen import K, sh, fl, sk, gr, layer, hx, YEL, YEL_D, WHITE, magnifier_shapes
from gen4 import (build_body, pupil_group, arc, brow, rays, star4, ell, eye_anim, PUPIL_L, PUPIL_R, ROOT_PIV,
                  C_HEAD, C_PUPIL, BLACK, HERE)

STAGE = ((375, 0), (360, 118), 82)
RED, RED_D = hx('#FF4D6D'), hx('#D92C4E')
P0 = list(ROOT_PIV)

def up(d): return [ROOT_PIV[0], ROOT_PIV[1] - d]

def offs(pc, keys):
    return K([(t, [pc[0] + dx, pc[1] + dy], *e) for (t, (dx, dy), *e) in keys])

def blink(blinks, N):
    ps, ao = [(0, [100, 100])], [(0, 0, 'hold')]
    for b in blinks:
        ps += [(b - 3, [100, 100], 'in'), (b, [100, 8], 'hold'), (b + 3, [100, 8], 'out'), (b + 6, [100, 100])]
        ao += [(b, 100, 'hold'), (b + 3, 0, 'hold')]
    ps.append((N, [100, 100])); ao.append((N, 0))
    return K(ps), K(ao)

LOBE_L, LOBE_R, LOBE_RAD = (249.07, 279.6), (496.69, 282.6), 131.5

def lid(side, y_off, edge_w=14, p=None):
    """Eyelid: the part of the eye lobe above a line, filled with head blue, with a dark lower edge."""
    (lx, ly), pc = (LOBE_L, PUPIL_L) if side == 'L' else (LOBE_R, PUPIL_R)
    y = pc[1] + y_off
    h = math.sqrt(max(LOBE_RAD ** 2 - (y - ly) ** 2, 1))
    a0 = math.atan2(y - ly, -h)          # left intersection
    a1 = math.atan2(y - ly, h)           # right intersection
    pts, n = [], 36
    for k in range(n + 1):               # sweep over the top, from left point clockwise to right point
        a = a0 + (a1 - a0 + (2 * math.pi if a1 < a0 else 0)) * k / n
        pts.append([round(lx + LOBE_RAD * math.cos(a), 2), round(ly + LOBE_RAD * math.sin(a), 2)])
    shape = sh(pts)
    edge = sh([[lx - h + 14, y + 2], [lx + h - 14, y + 2]], closed=False)
    a = (lx, y)
    return gr([gr([edge, sk(C_PUPIL, edge_w)], "lid-edge"), gr([shape, fl(C_HEAD)], "lid")], f'lid-{side}', a=a, p=p or a)

def heart_path(c, R):
    x, y = c
    P = lambda a, b: [x + a * R, y + b * R]
    T = lambda a, b: [a * R, b * R]
    return sh([P(0, -0.3), P(1, -0.05), P(0, 1), P(-1, -0.05)],
              i=[T(-0.15, -0.45), T(0, -0.55), T(0.3, -0.3), T(0, 0.5)],
              o=[T(0.15, -0.45), T(0, 0.5), T(-0.3, -0.3), T(0, -0.55)])

def heart_eye(side, N):
    pc = PUPIL_L if side == 'L' else PUPIL_R
    pulse = K([(0, [100, 100]), (8, [118, 118], 'out'), (16, [100, 100]), (24, [112, 112], 'out'), (32, [100, 100]), (N, [100, 100])])
    shine = gr([ell(pc[0] - 22, pc[1] - 14, 10, 8), fl(WHITE, 85)], "shine")
    h = gr([heart_path(pc, 58), sk(RED_D, 4), fl(RED)], "heart")
    return gr([shine, h], f'heart-eye-{side}', a=(pc[0], pc[1] + 10), p=(pc[0], pc[1] + 10), s=pulse)

def floating_hearts(ind, N):
    out = []
    for k, (x, y, R, t0) in enumerate([(560, 40, 30, 0), (650, -30, 24, 20), (610, 10, 18, 40)]):
        p = K([(0, [x, y + 60], 'hold'), (t0, [x, y + 60], 'out'), (t0 + 40, [x + 20, y - 40]), (N, [x + 20, y - 40])])
        o = K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + 6, 100), (t0 + 30, 100, 'lin'), (t0 + 40, 0, 'hold'), (N, 0)])
        s = K([(0, [40, 40], 'hold'), (t0, [40, 40], 'back'), (t0 + 12, [100, 100]), (N, [100, 100])])
        r = K([(0, -10), (N // 2, 10), (N, -10)])
        out.append(layer('heart', ind + k, [gr([heart_path((x, y), R), fl(RED)], "heart")], a=(x, y), p=p, o=o, s=s, r=r, N=N))
    return out

def exclaims(c, ind, N):
    x, y = c
    items = []
    for dx, rot in ((-30, -12), (30, 12)):
        bar = gr([sh([[x + dx, y - 70], [x + dx, y - 10]], closed=False), sk(YEL, 26)], "bar")
        dot = gr([ell(x + dx, y + 26, 14), fl(YEL)], "dot")
        items.append(gr([bar, dot], "mark", a=(x + dx, y + 30), p=(x + dx, y + 30), r=rot))
    s = K([(0, [0, 0], 'hold'), (2, [0, 0], 'back'), (12, [100, 100]), (40, [100, 100]), (48, [92, 92]), (56, [100, 100]), (N, [100, 100])])
    r = K([(12, 0), (16, -6), (20, 6), (24, 0), (N, 0)])
    return layer('exclaim', ind, items, a=(x, y + 40), s=s, r=r, N=N)

def question(c, ind, N):
    x, y = c
    hook = sh([[x - 32, y - 36], [x, y - 66], [x + 32, y - 34], [x, y], [x, y + 18]],
              i=[[0, 0], [-22, 0], [0, -24], [0, -10], [0, 0]], o=[[0, -22], [22, 0], [0, 20], [0, 8], [0, 0]], closed=False)
    shapes = [gr([ell(x, y + 52, 12), fl(YEL)], "dot"), gr([hook, sk(YEL, 22)], "hook")]
    return layer('question', ind, shapes, a=(x, y + 60), r=K([(0, -8), (N // 2, 8), (N, -8)]),
                 s=K([(0, [100, 100]), (N // 2, [108, 108]), (N, [100, 100])]), N=N)

def star_layer(c, R, ind, N, phase=0):
    s = K([(0, [100, 100]), ((N // 4 + phase) % N or 1, [70, 70]), (N, [100, 100])])
    return layer('sparkle', ind, [star4(c, R, YEL)], a=c, s=s, r=K([(0, 0), (N, 90)]), N=N)

def breathe(N, amt=1.2):
    return {'root_s': [(0, [100, 100]), (N // 2, [100 + amt * 0.5, 100 + amt]), (N, [100, 100])]}

def build(name, N, spec, face, fx=None):
    return build_body(name, N, spec, face=face, fx=fx, stage=STAGE)

E = {}

# 1 Neutral
N = 120
sb, ab = blink([40, 96], N)
look = [(0, (0, 0)), (20, (0, 0)), (28, (-22, 2)), (52, (-22, 2)), (60, (22, 2)), (84, (22, 2)), (92, (0, 0)), (N, (0, 0))]
E['neutral'] = build('Neutral', N, dict(breathe(N), head_r=[(0, 0), (40, -2), (84, 2), (N, 0)]), [
    arc('L', 'down', o=ab, w=16, dy=-10), arc('R', 'down', o=ab, w=16, dy=-10),
    pupil_group('L', {'p': offs(PUPIL_L, look), 's': sb, 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, look), 's': sb, 'o': 100})])

# 2 Happy
N = 60
squish = K([(0, [100, 100]), (15, [104, 112]), (30, [100, 100]), (45, [104, 112]), (60, [100, 100])])
E['happy'] = build('Happy', N, {
    'root_p': [(0, P0), (15, up(14), 'in'), (30, P0), (45, up(14), 'in'), (60, P0)],
    'head_r': [(0, -3), (30, 3), (60, -3)],
    'wingL': [(0, 0), (15, 6), (30, 0), (45, 6), (60, 0)], 'wingR': [(0, 0), (15, -6), (30, 0), (45, -6), (60, 0)],
}, [arc('L', 'up', s=squish), arc('R', 'up', s=squish)], fx=[rays((650, 60), -50, [], 20, 60, loop=True)])

# 3 Star-struck
N = 60
pulse = K([(0, [100, 100]), (10, [110, 110]), (20, [100, 100]), (30, [110, 110]), (40, [100, 100]), (60, [100, 100])])
def star_pupil(side):
    pc = PUPIL_L if side == 'L' else PUPIL_R
    s_ = gr([star4(pc, 44, YEL)], "star-wobble", a=pc, p=pc, r=K([(0, -10), (15, 10), (30, -10), (45, 10), (60, -10)]))
    return pupil_group(side, {'p': list(pc), 's': pulse, 'o': 100}, extra=[s_], hl=False)
E['star-struck'] = build('Star-Struck', N, {
    'root_s': [(0, [100, 100]), (6, [103, 97]), (12, [99, 102]), (20, [100, 100]), (60, [100, 100])],
    'root_p': [(0, P0), (8, up(10), 'in'), (16, P0), (60, P0)],
}, [star_pupil('L'), star_pupil('R')], fx=[star_layer((650, 40), 40, 20, N), star_layer((700, 120), 22, 21, N, 15)])

# 4 Wink
N = 75
wink_s = K([(0, [100, 100]), (4, [100, 100], 'in'), (8, [100, 10], 'hold'), (60, [100, 10], 'out'), (66, [100, 100]), (N, [100, 100])])
wink_o = K([(0, 100, 'hold'), (8, 0, 'hold'), (60, 100, 'hold'), (N, 100)])
arc_o = K([(0, 0, 'hold'), (8, 100, 'hold'), (60, 0, 'hold'), (N, 0)])
E['wink'] = build('Wink', N, {'head_r': [(0, 0), (10, 5), (60, 5), (68, 0), (N, 0)]}, [
    arc('R', 'up', o=arc_o, s=K([(8, [100, 40], 'out'), (12, [100, 100]), (56, [100, 100], 'in'), (60, [100, 40])])),
    pupil_group('R', {'p': list(PUPIL_R), 's': wink_s, 'o': wink_o}),
    pupil_group('L', {'p': offs(PUPIL_L, [(0, (0, 0)), (10, (6, -4)), (60, (6, -4)), (66, (0, 0)), (N, (0, 0))]), 's': [100, 100], 'o': 100}),
], fx=[rays((650, 50), -50, [(8, 62)], 20, N)])

# 5 Shocked (!!)
N = 90
shrink = K([(0, [100, 100]), (6, [74, 74], 'out'), (14, [82, 82]), (N, [82, 82])])
E['shocked'] = build('Shocked', N, {
    'root_p': [(0, P0), (5, up(30), 'out'), (14, up(-6)), (22, P0), (N, P0)],
    'root_s': [(0, [100, 100]), (5, [96, 105], 'out'), (14, [103, 97]), (22, [100, 100]), (N, [100, 100])],
    'wingL': [(0, 0), (5, 20, 'out'), (20, 12), (N, 12)], 'wingR': [(0, 0), (5, -20, 'out'), (20, -12), (N, -12)],
}, [pupil_group('L', {'p': offs(PUPIL_L, [(0, (0, 0)), (6, (6, -8)), (N, (6, -8))]), 's': shrink, 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, [(0, (0, 0)), (6, (-6, -8)), (N, (-6, -8))]), 's': shrink, 'o': 100})],
   fx=[exclaims((560, -30), 20, N)])

# 6 Thinking (wing on chin, ?)
N = 120
th = [(0, (30, -34)), (40, (38, -30)), (80, (24, -38)), (N, (30, -34))]
E['thinking'] = build('Thinking', N, {
    'wingR': [(0, 158), (30, 161), (60, 155), (90, 161), (N, 158)],
    'wingR_s': [(0, [68, 68]), (N, [68, 68])],
    'head_r': [(0, 4), (60, 7), (N, 4)],
    **breathe(N),
}, [lid('L', -18), brow('R', 'raised', p=K([(0, [481.02, 193.86]), (60, [481.02, 186]), (N, [481.02, 193.86])])),
    pupil_group('L', {'p': offs(PUPIL_L, th), 's': [100, 100], 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, th), 's': [100, 100], 'o': 100})],
   fx=[question((640, 10), 20, N)])

# 7 Calm
N = 90
E['calm'] = build('Calm', N, dict(breathe(N, 1.6), head_r=[(0, -3), (45, -6), (N, -3)]),
                  [arc('L', 'down'), arc('R', 'down')], fx=[star_layer((640, 40), 34, 20, N), star_layer((700, 110), 18, 21, N, 20)])

# 8 Unimpressed (heavy lids)
N = 120
gl = [(0, (14, 18)), (50, (14, 18)), (60, (-14, 18)), (100, (-14, 18)), (110, (14, 18)), (N, (14, 18))]
E['unimpressed'] = build('Unimpressed', N, dict(breathe(N, 0.8), head_r=[(0, 0), (55, -2), (105, 2), (N, 0)]), [
    lid('L', -6, 16), lid('R', -6, 16),
    pupil_group('L', {'p': offs(PUPIL_L, gl), 's': [100, 100], 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, gl), 's': [100, 100], 'o': 100})])

# 9 In Love
N = 60
E['in-love'] = build('In Love', N, {
    'head_r': [(0, -4), (30, 4), (60, -4)],
    'root_p': [(0, P0), (30, up(10)), (60, P0)],
}, [heart_eye('L', N), heart_eye('R', N)], fx=floating_hearts(20, N))

# 10 Cheerful (wings up, rays)
N = 60
cheer_L = [(0, 30), (8, 55), (15, 30), (23, 55), (30, 30), (38, 55), (45, 30), (53, 55), (60, 30)]
E['cheerful'] = build('Cheerful', N, {
    'wingL': cheer_L, 'wingR': [(t, -v) for t, v in cheer_L],
    'root_p': [(0, P0), (8, up(16), 'in'), (15, P0), (23, up(16), 'in'), (30, P0), (38, up(16), 'in'), (45, P0), (53, up(16), 'in'), (60, P0)],
    'head_r': [(0, -2), (30, 2), (60, -2)],
}, [arc('L', 'up', s=squish), arc('R', 'up', s=squish)], fx=[rays((660, 50), -50, [], 20, N, loop=True)])

if __name__ == '__main__':
    out = os.path.join(HERE, 'json')
    for f in os.listdir(out):
        if f.startswith('owl-expr-'):
            os.remove(os.path.join(out, f))
    for k, v in E.items():
        fp = os.path.join(out, f'owl-expr-{k}.json')
        json.dump(v, open(fp, 'w'), separators=(',', ':'))
        print(k, os.path.getsize(fp) // 1024, 'KB')
