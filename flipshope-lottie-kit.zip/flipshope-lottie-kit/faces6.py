"""Six head-only (face) animations on the v5 shaded rig, for avatars, loaders and in-app alerts."""
import json, math, os
from gen import K, sh, fl, sk, gr, layer, null, hx, el, YEL, WHITE
from gen4 import arc, rays, ell, PUPIL_L, PUPIL_R, comp
from gen5 import head_shapes, eye_mask, beak, pupil_group, free_icon, pop_keys, icon, NAVY, grad, HERE
from expr import blink, offs

HC = (375, 300)            # rig pivot (centre of head)
STAGE = ((375, 270), (360, 392), 80)
BLUE = hx('#1E4DFF')

def head_with_ears(earL_r=None, earR_r=None):
    g = head_shapes()
    head, earL, earR = g[:4], g[4:7], g[7:10]
    gl = gr(earL, 'ear-L', a=(190, 120), p=(190, 120), r=K(earL_r) if earL_r else 0)
    grr = gr(earR, 'ear-R', a=(560, 120), p=(560, 120), r=K(earR_r) if earR_r else 0)
    return head + [gl, grr]

def face_anim(name, N, face, rig=None, head_r=None, face_p=None, ears=None, fx=None, back=None):
    """face: shape groups for the face (top first). rig: dict p/s/r keyframes. back: layers behind the head."""
    rig = rig or {}
    g = lambda k, d: K(rig[k]) if k in rig else d
    ears = ears or {}
    layers = list(fx or [])
    layers.append(layer('face', 4, face + [beak(), eye_mask()], a=(375, 280), p=K(face_p) if face_p else [375, 280], parent=3, N=N))
    layers.append(layer('head', 3, head_with_ears(ears.get('L'), ears.get('R')), a=HC, p=list(HC),
                        r=K(head_r) if head_r else 0, parent=1, N=N))
    layers += list(back or [])
    layers.append(layer('shadow', 5, [gr([el((375, 575), (420, 40)), grad('radial', (375, 575), (585, 575), [(0, NAVY), (1, NAVY)], [(0, 0.22), (1, 0)])], 'shadow')],
                        a=(375, 575), s=g('shadow', [100, 100]), N=N))
    layers.append(null('rig', 1, a=HC, p=g('p', list(HC)), s=g('s', [100, 100]), r=g('r', 0), N=N))
    for L in layers:
        L.setdefault('parent', 99)
    layers.append(null('stage', 99, a=STAGE[0], p=STAGE[1], s=(STAGE[2], STAGE[2]), N=N))
    return comp(name, N, layers)

def FP(dx, dy=0): return [375 + dx, 280 + dy]
def UP(d): return [HC[0], HC[1] - d]
def breathe(N, amt=1.5):
    return [(0, [100, 100]), (N // 2, [100 + amt * 0.6, 100 - amt * 0.6]), (N, [100, 100])]

F = {}

# 1 Idle avatar: looks around, blinks, ear twitch
N = 120
sb, ab = blink([36, 98], N)
look = [(0, (0, 0)), (16, (0, 0)), (24, (-24, 2)), (48, (-24, 2)), (56, (24, 2)), (80, (24, 2)), (88, (0, 0)), (N, (0, 0))]
F['idle'] = face_anim('Face · Idle', N, [
    arc('L', 'down', o=ab, w=16, dy=-10), arc('R', 'down', o=ab, w=16, dy=-10),
    pupil_group('L', {'p': offs(PUPIL_L, look), 's': sb, 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, look), 's': sb, 'o': 100})],
    rig={'s': breathe(N)},
    head_r=[(0, 0), (16, 0), (24, -3), (48, -3), (56, 3), (80, 3), (88, 0), (N, 0)],
    face_p=[(0, FP(0)), (16, FP(0)), (24, FP(-14)), (48, FP(-14)), (56, FP(14)), (80, FP(14)), (88, FP(0)), (N, FP(0))],
    ears={'L': [(0, 0), (100, 0), (104, -10), (108, 4), (112, 0), (N, 0)], 'R': [(0, 0), (60, 0), (64, 10), (68, -4), (72, 0), (N, 0)]})

# 2 Loading: pupils circle, orbiting dot
N = 48
R_ = 26
circ = [(int(N * k / 8), (round(R_ * math.cos(2 * math.pi * k / 8 - math.pi / 2), 1), round(R_ * math.sin(2 * math.pi * k / 8 - math.pi / 2), 1)), 'lin') for k in range(9)]
orbit = layer('orbit', 20, [gr([el((375, -60), (34, 34)), fl(YEL)], 'dot'), gr([el((375, -60), (34, 34)), sk(hx('#D99400'), 4)], 'dot-edge')],
              a=(375, 290), p=[375, 290], r=K([(0, 0, 'lin'), (N, 360)]), N=N)
track = layer('track', 21, [gr([el((375, 290), (700, 700)), sk(BLUE, 6, 18)], 'track')], a=(375, 290), N=N)
F['loading'] = face_anim('Face · Loading', N, [
    pupil_group('L', {'p': offs(PUPIL_L, circ), 's': [100, 100], 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, circ), 's': [100, 100], 'o': 100})],
    head_r=[(0, -2), (N // 2, 2), (N, -2)], face_p=[(t, FP(round(v[0] * 0.3, 1), round(v[1] * 0.2, 1)), 'lin') for t, v, _ in circ],
    fx=[orbit], back=[track])

# 3 Typing / thinking: eyes up-right, then down to the message, dots bubble
N = 90
th = [(0, (26, -30)), (34, (34, -26)), (44, (0, 16)), (72, (-10, 16)), (82, (26, -30)), (N, (26, -30))]
dots = []
for k in range(3):
    x = 560 + k * 46
    t0 = k * 6
    p = K([(0, [x, 470]), (t0 + 6, [x, 470]), (t0 + 12, [x, 452], 'out'), (t0 + 18, [x, 470]), (t0 + 36, [x, 470]), (t0 + 42, [x, 452], 'out'),
           (t0 + 48, [x, 470]), (N, [x, 470])])
    dots.append(gr([el((0, 0), (28, 28)), fl(hx('#5A6488'))], f'dot{k}', p=p))
bubble = layer('typing-bubble', 20, dots + [gr([{"ty": "rc", "p": {"a": 0, "k": [606, 470]}, "s": {"a": 0, "k": [190, 92]}, "r": {"a": 0, "k": 46}, "d": 1, "nm": "rect"},
                                                 fl(WHITE), sk(hx('#DCE3F7'), 5)], 'bubble')],
               a=(606, 470), s=pop_keys(2, None, N), N=N)
F['typing'] = face_anim('Face · Typing', N, [
    pupil_group('L', {'p': offs(PUPIL_L, th), 's': [100, 100], 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, th), 's': [100, 100], 'o': 100})],
    head_r=[(0, 5), (34, 7), (44, -2), (72, -2), (82, 5), (N, 5)],
    face_p=[(0, FP(10, -4)), (34, FP(12, -4)), (44, FP(-2, 4)), (72, FP(-4, 4)), (82, FP(10, -4)), (N, FP(10, -4))],
    fx=[bubble])

# 4 New alert: jolt, ears perk, eyes widen, bell rings
N = 72
shrink = K([(0, [100, 100]), (6, [76, 76], 'out'), (16, [84, 84]), (54, [84, 84]), (64, [100, 100]), (N, [100, 100])])
bell = free_icon('bell', (690, 40), 170, 20, N, s=pop_keys(4, 64, N),
                 r=K([(0, 0), (10, 0), (14, 22), (18, -22), (22, 18), (26, -18), (30, 12), (34, -8), (38, 0), (N, 0)]))
F['alert'] = face_anim('Face · New Alert', N, [
    pupil_group('L', {'p': offs(PUPIL_L, [(0, (0, 0)), (6, (10, -10)), (54, (10, -10)), (64, (0, 0)), (N, (0, 0))]), 's': shrink, 'o': 100}),
    pupil_group('R', {'p': offs(PUPIL_R, [(0, (0, 0)), (6, (10, -10)), (54, (10, -10)), (64, (0, 0)), (N, (0, 0))]), 's': shrink, 'o': 100})],
    rig={'p': [(0, list(HC)), (5, UP(40), 'out'), (14, UP(-6)), (20, list(HC)), (N, list(HC))],
         's': [(0, [100, 100]), (5, [95, 106], 'out'), (14, [104, 96]), (22, [100, 100]), (N, [100, 100])],
         'shadow': [(0, [100, 100]), (5, [82, 82], 'out'), (14, [104, 104]), (22, [100, 100]), (N, [100, 100])]},
    head_r=[(0, 0), (8, 4), (54, 4), (64, 0), (N, 0)], face_p=[(0, FP(0)), (8, FP(10)), (54, FP(10)), (64, FP(0)), (N, FP(0))],
    ears={'L': [(0, 0), (5, -14, 'out'), (14, 4), (20, 0), (N, 0)], 'R': [(0, 0), (5, 14, 'out'), (14, -4), (20, 0), (N, 0)]},
    fx=[bell, rays((90, 120), -140, [(6, 40)], 21, N)])

# 5 Deal found: happy eyes, double bounce, sparkles
N = 60
squish = K([(0, [100, 100]), (10, [104, 114]), (20, [100, 100]), (30, [104, 114]), (40, [100, 100]), (N, [100, 100])])
F['deal-found'] = face_anim('Face · Deal Found', N, [arc('L', 'up', s=squish), arc('R', 'up', s=squish)],
    rig={'p': [(0, list(HC)), (10, UP(34), 'in'), (20, list(HC)), (30, UP(22), 'in'), (40, list(HC)), (N, list(HC))],
         's': [(0, [104, 96]), (6, [97, 104]), (18, [104, 96]), (26, [98, 103]), (38, [103, 97]), (46, [100, 100]), (N, [104, 96])],
         'shadow': [(0, [100, 100]), (10, [80, 80], 'in'), (20, [100, 100]), (30, [88, 88], 'in'), (40, [100, 100]), (N, [100, 100])]},
    head_r=[(0, -4), (20, 4), (40, -4), (N, -4)],
    ears={'L': [(0, 0), (10, -8), (20, 0), (30, -8), (40, 0), (N, 0)], 'R': [(0, 0), (10, 8), (20, 0), (30, 8), (40, 0), (N, 0)]},
    fx=[free_icon('sparkles', (650, 50), 160, 20, N, s=K([(0, [80, 80]), (15, [110, 110]), (30, [80, 80]), (45, [110, 110]), (N, [80, 80])])),
        free_icon('sparkles', (90, 110), 100, 21, N, s=K([(0, [110, 110]), (15, [80, 80]), (30, [110, 110]), (45, [80, 80]), (N, [110, 110])])),
        rays((640, 380), 10, [(8, 34), (32, 56)], 22, N)])

# 6 Offline / sleeping: closed eyes, slow nod, floating Zzz
N = 120
zs = []
for k, t0 in enumerate((0, 60)):
    p = K([(0, [620, 120]), (t0, [620, 120], 'out'), (t0 + 56, [690, -40]), (N, [690, -40])])
    o = K([(0, 0, 'hold'), (t0, 0, 'out'), (t0 + 8, 100), (t0 + 44, 100, 'lin'), (t0 + 56, 0, 'hold'), (N, 0)])
    s = K([(0, [60, 60], 'hold'), (t0, [60, 60], 'out'), (t0 + 40, [110, 110]), (N, [110, 110])])
    zs.append(free_icon('zzz', (620, 120), 150, 20 + k, N, p=p, o=o, s=s))
F['offline'] = face_anim('Face · Offline', N, [arc('L', 'down'), arc('R', 'down')],
    rig={'p': [(0, list(HC)), (60, UP(-12)), (N, list(HC))], 's': [(0, [100, 100]), (60, [102, 98]), (N, [100, 100])]},
    head_r=[(0, -2), (60, 6), (N, -2)], face_p=[(0, FP(0, -2)), (60, FP(-6, 6)), (N, FP(0, -2))],
    ears={'L': [(0, 0), (60, 6), (N, 0)], 'R': [(0, 0), (60, -6), (N, 0)]},
    fx=zs)

if __name__ == '__main__':
    out = os.path.join(HERE, 'json')
    for f in os.listdir(out):
        if f.startswith('owl-face-'):
            os.remove(os.path.join(out, f))
    for k, v in F.items():
        fp = os.path.join(out, f'owl-face-{k}.json')
        json.dump(v, open(fp, 'w'), separators=(',', ':'))
        print(k, v['op'], 'frames', os.path.getsize(fp) // 1024, 'KB')
