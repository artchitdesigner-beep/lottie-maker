"""Generates Lottie JSON animations for the blue owl mascot."""
import json, math, os

FR = 30
W = H = 512

def hx(h, a=1):
    h = h.lstrip('#')
    return [round(int(h[i:i+2], 16) / 255, 4) for i in (0, 2, 4)] + [a]

BLUE   = hx('#2246CF')
BLUE_D = hx('#132B8C')
BLUE_L = hx('#4A6FF0')
YEL    = hx('#FFC61A')
YEL_D  = hx('#D99400')
WHITE  = hx('#FFFFFF')
INK    = hx('#0E1446')
LENS   = hx('#EAF1FF')

EASES = {
    'ease': (0.45, 0, 0.55, 1),
    'out':  (0.2, 0.7, 0.3, 1),
    'in':   (0.6, 0, 0.85, 0.4),
    'lin':  (0.0, 0.0, 1, 1),
    'back': (0.34, 1.0, 0.5, 1.45),  # overshoot
}

def st(v):
    return {"a": 0, "k": v}

def K(frames):
    """frames: list of (t, value[, ease]); ease applies from that key to the next."""
    ks = []
    for i, f in enumerate(frames):
        t, v = f[0], f[1]
        e = f[2] if len(f) > 2 else 'ease'
        k = {"t": t, "s": list(v) if isinstance(v, (list, tuple)) else [v]}
        if i < len(frames) - 1:
            if e == 'hold':
                k["h"] = 1
            else:
                ox, oy, ix, iy = EASES[e]
                k["o"] = {"x": [ox], "y": [oy]}
                k["i"] = {"x": [ix], "y": [iy]}
        ks.append(k)
    return {"a": 1, "k": ks}

def val(x):
    if isinstance(x, dict):
        return x
    return st(list(x) if isinstance(x, (tuple, list)) else x)

# ---------- shape primitives ----------
def el(c, s):
    return {"ty": "el", "p": val(list(c)), "s": val(list(s)), "d": 1, "nm": "ellipse"}

def rc(c, s, r):
    return {"ty": "rc", "p": val(list(c)), "s": val(list(s)), "r": st(r), "d": 1, "nm": "rect"}

def sh(v, i=None, o=None, closed=True):
    n = len(v)
    i = i or [[0, 0]] * n
    o = o or [[0, 0]] * n
    return {"ty": "sh", "d": 1, "nm": "path",
            "ks": st({"v": [list(p) for p in v], "i": [list(p) for p in i],
                      "o": [list(p) for p in o], "c": closed})}

def fl(c, o=100):
    return {"ty": "fl", "c": st(c), "o": val(o), "r": 1, "nm": "fill"}

def sk(c, w, o=100):
    return {"ty": "st", "c": st(c), "o": val(o), "w": st(w), "lc": 2, "lj": 2, "nm": "stroke"}

def tr(p=(0, 0), a=(0, 0), s=(100, 100), r=0, o=100):
    return {"ty": "tr", "p": val(p), "a": val(a), "s": val(s), "r": val(r), "o": val(o),
            "sk": st(0), "sa": st(0)}

def gr(items, nm="group", **t):
    return {"ty": "gr", "nm": nm, "it": items + [tr(**t)]}

def layer(nm, ind, shapes, a, p=None, s=(100, 100), r=0, o=100, parent=None, N=60):
    L = {"ddd": 0, "ind": ind, "ty": 4, "nm": nm, "sr": 1, "ao": 0, "bm": 0,
         "ks": {"a": val(list(a)), "p": val(p if p is not None else list(a)),
                "s": val(s), "r": val(r), "o": val(o)},
         "shapes": shapes, "ip": 0, "op": N, "st": 0}
    if parent:
        L["parent"] = parent
    return L

def null(nm, ind, a, p=None, s=(100, 100), r=0, N=60):
    return {"ddd": 0, "ind": ind, "ty": 3, "nm": nm, "sr": 1, "ao": 0, "bm": 0,
            "ks": {"a": val(list(a)), "p": val(p if p is not None else list(a)),
                   "s": val(s), "r": val(r), "o": st(0)},
            "ip": 0, "op": N, "st": 0}

def mirror(pts):
    return [[W - x, y] for x, y in pts]

# ---------- character geometry ----------
SHOULDER_L = (164, 300)
SHOULDER_R = (348, 300)
WING_BASE_R = 32           # rest outward tilt
EYE_L = (202, 182)
EYE_R = (310, 182)
EAR_L = [[130, 150], [146, 50], [226, 100]]

def ear_shape(pts, flip=False):
    a, b, c = pts
    f = -1 if flip else 1
    i = [[0, 0], [-6 * f, 20], [-26 * f, -14]]
    o = [[2 * f, -34], [18 * f, 6], [0, 0]]
    return sh([a, b, c], i=i, o=o)

def head_shapes():
    shapes = lambda: [ear_shape(EAR_L), ear_shape(mirror(EAR_L), True), el((256, 186), (266, 208))]
    outline = gr([gr([x, sk(BLUE_D, 12), fl(BLUE_D)], "o") for x in shapes()], "head-outline")
    fill = gr([gr([x, sk(BLUE, 3), fl(BLUE)], "f") for x in shapes()], "head-fill")
    hl = gr([el((0, 0), (64, 22)), fl(WHITE, 10)], "head-shine", p=(200, 108), r=-18)
    # brow dip between eyes (darker V)
    brow = gr([sh([[226, 128], [256, 146], [286, 128]], closed=False), sk(BLUE_D, 5, 45)], "brow")
    return [hl, brow, fill, outline]

def body_shapes():
    s = lambda: [el((256, 346), (234, 196))]
    return [gr(s() + [fl(BLUE)], "body-fill"),
            gr(s() + [sk(BLUE_D, 12), fl(BLUE_D)], "body-outline")]

def logo(c):
    x, y = c
    blue = gr([rc((x - 13, y), (13, 44), 4), rc((x + 1, y - 16), (40, 12), 4), rc((x - 2, y), (30, 11), 4),
               fl(BLUE)], "logo-F")
    yel = gr([sh([[x + 18, y - 4], [x + 18, y + 10], [x + 4, y + 22]],
                 i=[[0, 0], [0, -4], [8, 0]], o=[[0, 4], [0, 8], [0, 0]], closed=False),
              sk(YEL, 9)], "logo-tail")
    return [yel, blue]

def front_shapes():
    collar_v = [[168, 256], [344, 256], [344, 280], [168, 280]]
    collar_i = [[0, 0], [-60, 22], [0, 0], [60, 22]]
    collar_o = [[60, 22], [0, 0], [-60, 22], [0, 0]]
    collar = gr([sh(collar_v, collar_i, collar_o), sk(YEL_D, 4), fl(YEL)], "collar")
    clasp = gr([rc((256, 284), (40, 28), 9), sk(YEL_D, 4), fl(YEL)], "clasp")
    clasp_line = gr([rc((256, 284), (18, 4), 2), fl(YEL_D)], "clasp-line")
    straps = lambda: [sh([[196, 276], [170, 432]], o=[[-26, 42], [0, 0]], i=[[0, 0], [-2, -60]], closed=False),
                      sh([[316, 276], [342, 432]], o=[[26, 42], [0, 0]], i=[[0, 0], [2, -60]], closed=False)]
    ring = gr(straps() + [sk(YEL, 13)], "cape-straps")
    ring_d = gr(straps() + [sk(YEL_D, 19)], "cape-straps-dark")
    belly = gr([el((256, 364), (140, 126)), fl(WHITE)], "belly")
    belly_o = gr([el((256, 364), (140, 126)), sk(BLUE_D, 4, 35)], "belly-edge")
    return [clasp_line, clasp, collar, ring, ring_d] + logo((256, 362)) + [belly_o, belly]

def wing_shapes(side):
    sx, sy = SHOULDER_L if side == 'L' else SHOULDER_R
    rot = WING_BASE_R if side == 'L' else -WING_BASE_R
    s = lambda: [el((0, 56), (66, 122))]
    feather = gr([sh([[-11, 78], [0, 95], [11, 78]], closed=False), sk(BLUE_D, 4, 55)], "feather")
    return [gr([feather, gr(s() + [fl(BLUE)], "wing-fill"),
                gr(s() + [sk(BLUE_D, 11), fl(BLUE_D)], "wing-outline")],
               "wing", p=(sx, sy), r=rot)]

def foot_shapes(c):
    s = lambda: [el(c, (58, 28))]
    toes = gr([sh([[c[0] - 8, c[1] + 2], [c[0] - 8, c[1] + 12]], closed=False),
               sh([[c[0] + 8, c[1] + 2], [c[0] + 8, c[1] + 12]], closed=False), sk(YEL_D, 3, 70)], "toes")
    return [toes, gr(s() + [fl(YEL)], "foot-fill"), gr(s() + [sk(YEL_D, 8), fl(YEL_D)], "foot-outline")]

def eye_group(c, pupil_dir, happy, look, nm):
    cx, cy = c
    pc = (cx + pupil_dir, cy + 4)
    pupil = gr([
        gr([el((pc[0] + 10, pc[1] + 10), (8, 8)), fl(WHITE)], "hl2"),
        gr([el((pc[0] - 10, pc[1] - 10), (18, 18)), fl(WHITE)], "hl1"),
        gr([el(pc, (60, 60)), fl(INK)], "pupil"),
    ], "pupil-grp", a=pc, p=look['p'], s=look['s'], o=look['o'])
    arc = gr([sh([[cx - 28, cy + 9], [cx, cy - 14], [cx + 28, cy + 9]],
                 i=[[0, 0], [-15, 0], [-4, -10]], o=[[4, -10], [15, 0], [0, 0]], closed=False),
              sk(INK, 9)], "happy-arc", a=(cx, cy), p=(cx, cy), s=happy['s'], o=happy['o'])
    disc = gr([el(c, (118, 118)), sk(BLUE_D, 7), fl(WHITE)], "eye-white")
    return gr([arc, pupil, disc], nm)

def eye_anim(closed, base, look_keys, N):
    """closed: list of (start, end) frames with eye closed (happy arc)."""
    bx, by = base
    if look_keys:
        p = K([(t, [bx + dx, by + dy], *e) for (t, (dx, dy), *e) in look_keys])
    else:
        p = [bx, by]
    if not closed:
        return {'p': p, 's': [100, 100], 'o': 100}, {'s': [100, 100], 'o': 0}
    ps, po, hs, ho = [], [(0, 100, 'hold')], [], [(0, 0, 'hold')]
    for (a, b) in closed:
        ps += [(max(a - 3, 0), [100, 100], 'in'), (a, [100, 10], 'hold'), (b, [100, 10], 'out'), (b + 3, [100, 100])]
        po += [(a, 0, 'hold'), (b, 100, 'hold')]
        ho += [(a, 100, 'hold'), (b, 0, 'hold')]
        hs += [(a, [100, 30], 'out'), (a + 3, [100, 100]), (max(b - 3, a + 3), [100, 100], 'in'), (b, [100, 30])]
    po.append((N, 100)); ho.append((N, 0))
    look = {'p': p, 's': K(ps), 'o': K(po)}
    happy = {'s': K(hs), 'o': K(ho)}
    return look, happy

def face_shapes(spec, N):
    beak = gr([sh([[238, 226], [274, 226], [256, 256]],
                  i=[[0, -6], [8, -4], [6, 0]], o=[[-8, -4], [0, 6], [-6, 0]]), sk(YEL_D, 4), fl(YEL)], "beak")
    out = [beak]
    for side, c, pdir in (('L', EYE_L, 6), ('R', EYE_R, -6)):
        closed = spec.get('closed_' + side, spec.get('closed', []))
        look, happy = eye_anim(closed, (c[0] + pdir, c[1] + 4), spec.get('look'), N)
        out.append(eye_group(c, pdir, happy, look, 'eye-' + side))
    return out

exec(open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'geometry_v2.py')).read())

# ---------- props & fx ----------
def magnifier_shapes():
    cx, cy = 420, 166
    pct = gr([el((cx - 7, cy - 6), (9, 9)), el((cx + 7, cy + 7), (9, 9)),
              sh([[cx + 8, cy - 10], [cx - 8, cy + 11]], closed=False), sk(INK, 3.2)], "percent")
    tag = gr([sh([[cx - 16, cy - 17], [cx + 16, cy - 17], [cx + 16, cy + 6], [cx, cy + 20], [cx - 16, cy + 6]]),
              sk(YEL_D, 4), fl(YEL)], "tag")
    glint = gr([sh([[cx - 26, cy - 4], [cx - 14, cy - 24]], i=[[0, 0], [-10, 2]], o=[[0, -10], [0, 0]], closed=False),
                sk(WHITE, 4, 90)], "glint")
    lens = gr([el((cx, cy), (72, 72)), fl(LENS)], "lens")
    ring = gr([el((cx, cy), (78, 78)), sk(YEL, 10)], "ring")
    ring_d = gr([el((cx, cy), (78, 78)), sk(YEL_D, 16)], "ring-dark")
    handle = gr([rc((cx, cy + 56), (16, 36), 8), sk(YEL_D, 4), fl(YEL)], "handle")
    return [pct, tag, glint, ring, ring_d, lens, handle]

def bell_shapes(swing):
    cx = 420
    body = gr([sh([[388, 214], [402, 190], [420, 154], [438, 190], [452, 214]],
                  i=[[0, 0], [0, 12], [-16, 0], [0, -22], [-8, -8]],
                  o=[[8, -8], [0, -22], [16, 0], [0, 12], [0, 0]]), sk(YEL_D, 4), fl(YEL)], "bell")
    shine = gr([sh([[404, 200], [414, 168]], i=[[0, 0], [-6, 6]], o=[[0, -14], [0, 0]], closed=False),
                sk(WHITE, 5, 75)], "shine")
    rim = gr([rc((cx, 216), (72, 11), 5.5), sk(YEL_D, 3), fl(YEL)], "rim")
    clap = gr([el((cx, 228), (16, 16)), fl(YEL_D)], "clapper")
    knob = gr([el((cx, 150), (14, 14)), sk(YEL_D, 3), fl(YEL)], "knob")
    handle = gr([rc((cx, 236), (14, 30), 7), sk(BLUE_D, 3), fl(BLUE)], "grip")
    return [gr([shine, rim, body, clap, knob], "bell-swing", a=(cx, 146), p=(cx, 146), r=swing), handle]

def sparkle(c, base_ang, vis, ind, N, color=YEL, size=1.0):
    x, y = c
    items = []
    for d in (-38, 0, 38):
        a = math.radians(base_ang + d)
        r1, r2 = 10 * size, 26 * size
        items.append(sh([[x + r1 * math.cos(a), y + r1 * math.sin(a)], [x + r2 * math.cos(a), y + r2 * math.sin(a)]],
                        closed=False))
    shapes = [gr(items + [sk(color, 7)], "rays")]
    ks_s, ks_o = [(0, [0, 0], 'hold')], [(0, 0, 'hold')]
    for (a, b) in vis:
        ks_s += [(a, [30, 30], 'back'), (a + 7, [100, 100]), (b - 5, [100, 100], 'in'), (b, [60, 60], 'hold')]
        ks_o += [(a, 100, 'hold'), (b - 5, 100, 'lin'), (b, 0, 'hold')]
    ks_s.append((N, [0, 0])); ks_o.append((N, 0))
    return layer('sparkle', ind, shapes, a=c, s=K(ks_s), o=K(ks_o), N=N)

def motion_lines(vis, ind, parent, N):
    items = []
    for x, d in ((192, -1), (176, -1), (320, 1), (336, 1)):
        items.append(sh([[x, 452], [x + 6 * d, 474]], i=[[0, 0], [-4 * d, -4]], o=[[4 * d, 6], [0, 0]], closed=False))
    shapes = [gr(items + [sk(BLUE, 5)], "lines")]
    ko = [(0, 0, 'hold')]
    for (a, b) in vis:
        ko += [(a, 100, 'hold'), (b - 4, 100, 'lin'), (b, 0, 'hold')]
    ko.append((N, 0))
    return layer('motion-lines', ind, shapes, a=(256, 460), o=K(ko), N=N)

def waves(vis, ind, N):
    items = []
    for x, r in ((466, 20), (482, 34)):
        items.append(sh([[x, 168 - r * 0.6], [x + 8, 190], [x, 212 + r * 0.2]],
                        i=[[0, 0], [0, -14], [6, -6]], o=[[6, 6], [0, 14], [0, 0]], closed=False))
    for x, r in ():
        items.append(sh([[x, 160], [x - 8, 182], [x, 204]],
                        i=[[0, 0], [0, -14], [-6, -6]], o=[[-6, 6], [0, 14], [0, 0]], closed=False))
    shapes = [gr(items + [sk(YEL, 6)], "waves")]
    a, b = vis
    s = [(0, [80, 80], 'hold'), (a, [80, 80], 'out')]
    t = a
    while t + 8 < b:
        s += [(t + 4, [112, 112]), (t + 8, [92, 92])]
        t += 8
    s += [(b, [100, 100], 'hold'), (N, [100, 100])]
    o = [(0, 0, 'hold'), (a, 0, 'out'), (a + 4, 100, 'hold'), (b - 6, 100, 'lin'), (b, 0, 'hold'), (N, 0)]
    return layer('ring-waves', ind, shapes, a=(420, 186), s=K(s), o=K(o), N=N)

CONF_COLORS = [hx('#9B5CF6'), YEL, hx('#2F6BFF'), hx('#FF5FA2'), hx('#22C55E'), hx('#9B5CF6'), YEL, hx('#2F6BFF')]

def confetti(t0, origin, ind0, N, count=14):
    layers = []
    for k in range(count):
        ang = -170 + k * (160 / (count - 1)) + (7 if k % 2 else -5)
        dist = 150 + (k * 37 % 70)
        a = math.radians(ang)
        tx, ty = origin[0] + dist * math.cos(a), origin[1] + dist * math.sin(a)
        col = CONF_COLORS[k % len(CONF_COLORS)]
        w, h = (10, 18) if k % 3 else (12, 12)
        shapes = [gr([rc((0, 0), (w, h), 3), fl(col)], "piece")]
        delay = (k % 4)
        s0 = t0 + delay
        p = K([(0, list(origin), 'hold'), (s0, list(origin), 'out'), (s0 + 18, [tx, ty], 'in'),
               (s0 + 40, [tx + 6 * math.cos(a), ty + 40], 'lin'), (N, [tx + 6 * math.cos(a), ty + 40])])
        r = K([(s0, 0, 'lin'), (s0 + 40, 360 * (1 if k % 2 else -1) * 1.5)])
        o = K([(0, 0, 'hold'), (s0, 100, 'hold'), (s0 + 28, 100, 'lin'), (s0 + 40, 0, 'hold'), (N, 0)])
        s = K([(0, [0, 0], 'hold'), (s0, [40, 40], 'out'), (s0 + 8, [100, 100]), (N, [100, 100])])
        layers.append(layer('confetti', ind0 + k, shapes, a=(0, 0), p=p, r=r, o=o, s=s, N=N))
    return layers

# ---------- rig assembly ----------
def grip_local(wing_rot, length=None):
    length = length or WING_LEN - 6
    """Point in wing-local (rest) space that lands at the wing tip after rotating the layer by wing_rot."""
    sx, sy = SHOULDER_R
    th = math.radians(-WING_BASE_R + wing_rot)
    tip = (sx - length * math.sin(th), sy + length * math.cos(th))
    th2 = math.radians(-wing_rot)
    dx, dy = tip[0] - sx, tip[1] - sy
    lx = sx + dx * math.cos(th2) - dy * math.sin(th2)
    ly = sy + dx * math.sin(th2) + dy * math.cos(th2)
    return [round(lx, 2), round(ly, 2)], tip

RAISE = -116

def build(name, N, spec):
    g = lambda k, d: K(spec[k]) if k in spec else d
    ROOT, BODY, HEAD, FACE, FRONT, WL, WR, FL_, FR_, SHAD, PROP = range(1, 12)
    layers = []
    ind = 20
    # fx
    for sp in spec.get('sparkles', []):
        layers.append(sparkle(sp['c'], sp.get('ang', -60), sp['vis'], ind, N, sp.get('color', YEL), sp.get('size', 1)))
        ind += 1
    if 'waves' in spec:
        layers.append(waves(spec['waves'], ind, N)); ind += 1
    # prop (parented to right wing, counter-rotated so it stays upright)
    if 'prop' in spec:
        gl, _ = grip_local(RAISE)
        if spec['prop'] == 'magnifier':
            shapes, a = magnifier_shapes(), (420, 238)
        else:
            shapes, a = bell_shapes(g('bell_r', 0)), (420, 250)
        layers.append(layer('prop', PROP, shapes, a=a, p=gl, r=-RAISE, s=g('prop_s', [0, 0]), parent=WR, N=N))
    HL, CAPE = 12, 13
    layers.append(layer('face', FACE, face_shapes(spec, N), a=(256, 190), parent=HEAD, N=N))
    layers.append(layer('foot-L', FL_, foot_shapes((226, 450)), a=(226, 450), p=g('footL', [226, 450]), parent=ROOT, N=N))
    layers.append(layer('foot-R', FR_, foot_shapes((286, 450)), a=(286, 450), p=g('footR', [286, 450]), parent=ROOT, N=N))
    layers.append(layer('front', FRONT, front_shapes(), a=(256, 340), parent=ROOT, N=N))
    layers.append(layer('wing-R', WR, wing_shapes('R'), a=SHOULDER_R, r=g('wingR', 0), parent=ROOT, N=N))
    layers.append(layer('wing-L', WL, wing_shapes('L'), a=SHOULDER_L, r=g('wingL', 0), parent=ROOT, N=N))
    layers.append(layer('head', HEAD, head_fill_shapes(), a=(256, 290), p=g('head_p', [256, 290]), r=g('head_r', 0),
                        parent=ROOT, N=N))
    layers.append(layer('body', BODY, body_shapes(), a=(256, 352), parent=ROOT, N=N))
    layers.append(layer('head-outline', HL, head_outline_shapes(), a=(256, 290), parent=HEAD, N=N))
    layers.append(layer('cape-back', CAPE, cape_back_shapes(), a=(256, 300), parent=ROOT, N=N))
    if 'lines' in spec:
        layers.append(motion_lines(spec['lines'], ind, ROOT, N)); ind += 1
    if 'confetti' in spec:
        layers += confetti(spec['confetti'], (256, 150), 60, N)
    layers.append(layer('shadow', SHAD, [gr([el((256, 462), (200, 24)), fl([0.05, 0.08, 0.25, 1], 14)], "shadow")],
                        a=(256, 456), s=g('shadow', [100, 100]), N=N))
    layers.append(null('rig', ROOT, a=(256, 456), p=g('root_p', [256, 456]), s=g('root_s', [100, 100]),
                       r=g('root_r', 0), N=N))
    for L in layers:
        if 'parent' not in L:
            L['parent'] = 99
    layers.append(null('stage', 99, a=(256, 456), p=(256, 474), s=(90, 90), N=N))
    return {"v": "5.12.2", "fr": FR, "ip": 0, "op": N, "w": W, "h": H, "nm": name, "ddd": 0,
            "assets": [], "layers": layers, "markers": []}

P0 = [256, 456]
def up(dy): return [256, 456 - dy]

ANIMS = {}

# 1. Idle blink -------------------------------------------------
N = 90
ANIMS['idle-blink'] = build('Idle Blink', N, {
    'root_s': [(0, [100, 100]), (10, [104, 95]), (15, [96, 105], 'out'), (22, [99, 101]), (27, [105, 95], 'out'),
               (33, [100, 100]), (60, [101, 99]), (90, [100, 100])],
    'root_p': [(0, P0), (13, P0, 'out'), (20, up(18), 'in'), (27, P0), (90, P0)],
    'shadow': [(0, [100, 100]), (13, [100, 100], 'out'), (20, [82, 82], 'in'), (27, [100, 100]), (90, [100, 100])],
    'head_r': [(0, 0), (40, -3), (70, 3), (90, 0)],
    'wingL': [(0, 0), (12, 0, 'out'), (19, 14), (27, 0), (90, 0)],
    'wingR': [(0, 0), (12, 0, 'out'), (19, -14), (27, 0), (90, 0)],
    'look': [(0, (0, 0)), (40, (0, 0)), (46, (-8, 1)), (60, (-8, 1)), (68, (8, 1)), (80, (8, 1)), (88, (0, 0)), (90, (0, 0))],
    'closed': [(62, 66)],
    'lines': [(25, 34)],
    'sparkles': [{'c': (380, 74), 'ang': -55, 'vis': [(20, 44)]}],
})

# 2. Walking ----------------------------------------------------
N = 32
ANIMS['walking'] = build('Walking', N, {
    'root_p': [(0, P0), (8, up(8)), (16, P0), (24, up(8)), (32, P0)],
    'root_r': [(0, -4), (16, 4), (32, -4)],
    'head_r': [(0, 2), (16, -2), (32, 2)],
    'footR': [(0, [286, 436]), (7, [286, 450]), (25, [286, 450]), (32, [286, 436])],
    'footL': [(0, [226, 450]), (9, [226, 450]), (16, [226, 436]), (23, [226, 450]), (32, [226, 450])],
    'wingL': [(0, 12), (16, -6), (32, 12)],
    'wingR': [(0, 6), (16, -12), (32, 6)],
    'shadow': [(0, [100, 100]), (8, [95, 100]), (16, [100, 100]), (24, [95, 100]), (32, [100, 100])],
})

# 3. Search / analyze -------------------------------------------
N = 100
ANIMS['search-analyze'] = build('Search / Analyze', N, {
    'prop': 'magnifier',
    'wingR': [(0, 0), (10, 0, 'out'), (22, RAISE), (36, RAISE + 8), (50, RAISE - 5), (64, RAISE + 6), (78, RAISE),
              (82, RAISE), (94, 0), (100, 0)],
    'prop_s': [(0, [0, 0], 'hold'), (12, [0, 0], 'back'), (26, [100, 100]), (80, [100, 100], 'in'), (90, [0, 0], 'hold'),
               (100, [0, 0])],
    'look': [(0, (0, 0)), (16, (0, 0)), (24, (10, -6)), (78, (10, -6)), (86, (0, 0)), (100, (0, 0))],
    'closed_L': [(46, 58)],
    'head_r': [(0, 0), (20, 0), (30, 5), (76, 5), (86, 0), (100, 0)],
    'root_s': [(0, [100, 100]), (50, [101, 99]), (100, [100, 100])],
    'sparkles': [{'c': (470, 112), 'ang': -50, 'vis': [(28, 44), (60, 76)]}],
})

# 4. Price alert ------------------------------------------------
N = 96
ANIMS['price-alert'] = build('Price Alert', N, {
    'prop': 'bell',
    'wingR': [(0, 0), (8, 0, 'out'), (20, RAISE), (76, RAISE), (88, 0), (96, 0)],
    'prop_s': [(0, [0, 0], 'hold'), (10, [0, 0], 'back'), (22, [100, 100]), (76, [100, 100], 'in'), (84, [0, 0], 'hold'),
               (96, [0, 0])],
    'bell_r': [(0, 0), (22, 0), (28, 22), (34, -22), (40, 20), (46, -20), (52, 14), (58, -10), (64, 5), (70, 0), (96, 0)],
    'waves': (26, 64),
    'closed': [(36, 54)],
    'look': [(0, (0, 0)), (14, (0, 0)), (22, (9, -5)), (74, (9, -5)), (84, (0, 0)), (96, (0, 0))],
    'root_r': [(0, 0), (24, 0), (28, 2), (32, -2), (36, 2), (40, -2), (44, 0), (96, 0)],
    'sparkles': [{'c': (470, 108), 'ang': -50, 'vis': [(22, 40)]}],
})

# 5. Celebrate --------------------------------------------------
N = 80
flapL = [(0, 0), (8, 0, 'out'), (16, 120), (20, 100), (24, 124), (28, 102), (32, 120), (40, 104), (48, 122), (56, 106),
         (62, 118), (72, 0), (80, 0)]
ANIMS['celebrate'] = build('Celebrate / Deal Found', N, {
    'root_s': [(0, [100, 100]), (8, [108, 90]), (13, [95, 106], 'out'), (24, [98, 103]), (32, [110, 90], 'out'),
               (40, [97, 103]), (46, [100, 100]), (50, [104, 95]), (54, [97, 104]), (62, [106, 94]), (68, [100, 100]),
               (80, [100, 100])],
    'root_p': [(0, P0), (10, P0, 'out'), (22, up(36), 'in'), (32, P0), (52, P0, 'out'), (57, up(22), 'in'), (62, P0),
               (80, P0)],
    'shadow': [(0, [100, 100]), (10, [100, 100], 'out'), (22, [62, 62], 'in'), (32, [100, 100]), (52, [100, 100], 'out'),
               (57, [84, 84], 'in'), (62, [100, 100]), (80, [100, 100])],
    'wingL': flapL,
    'wingR': [(t, -v, *e) for (t, v, *e) in flapL],
    'closed': [(8, 70)],
    'head_r': [(0, 0), (22, -4), (40, 4), (52, -3), (68, 0), (80, 0)],
    'confetti': 14,
    'lines': [(30, 42), (61, 69)],
    'sparkles': [{'c': (392, 70), 'ang': -50, 'vis': [(14, 36)]},
                 {'c': (120, 70), 'ang': -130, 'vis': [(18, 40)]}],
})

if __name__ == '__main__':
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'json')
    os.makedirs(out, exist_ok=True)
    for k, v in ANIMS.items():
        with open(os.path.join(out, f'owl-{k}.json'), 'w') as f:
            json.dump(v, f, separators=(',', ':'))
        print(k, v['op'], 'frames', os.path.getsize(os.path.join(out, f'owl-{k}.json')) // 1024, 'KB')
