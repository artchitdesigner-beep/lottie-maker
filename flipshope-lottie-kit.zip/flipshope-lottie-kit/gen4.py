"""Owl Lottie rig v3, built from the corrected SVG (owl-source-v4.svg, viewBox 755x923).
Outputs 5 full-body actions and 12 face-only expressions."""
import json, math, os, re
from svgpathtools import parse_path, Line, CubicBezier, QuadraticBezier
from gen import (st, K, sh, fl, sk, tr, gr, layer, null, el, rc, hx, magnifier_shapes, bell_shapes,
                 eye_anim, YEL, YEL_D, WHITE, CONF_COLORS)

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = open(os.path.join(HERE, 'owl-source-v4.svg')).read()
PATHS = re.findall(r'<path (?:id="[^"]+" )?d="([^"]+)"', SRC)

FR, CW, CH = 30, 720, 720
BLACK = hx('#000000')
C_BODY, C_HEAD, C_INNER = hx('#0248BC'), hx('#0148BD'), hx('#0249BD')
C_MASK, C_PUPIL, C_BEAK = hx('#FCFCFF'), hx('#011029'), hx('#FFD92D')
C_CAPE_D, C_CAPE, C_FOOT = hx('#DFA001'), hx('#FFD402'), hx('#FED303')
C_BEAK_D = hx('#E8A800')

# ---------- svg helpers ----------
def seg_cubic(seg):
    if isinstance(seg, Line):
        return seg.start, seg.start, seg.end, seg.end, True
    if isinstance(seg, QuadraticBezier):
        return (seg.start, seg.start + 2 / 3 * (seg.control - seg.start), seg.end + 2 / 3 * (seg.control - seg.end), seg.end, False)
    return seg.start, seg.control1, seg.control2, seg.end, False

def segs_to_sh(segs, closed=True):
    v, i, o = [], [], []
    for seg in segs:
        p0, c1, c2, p1, ln = seg_cubic(seg)
        if not v:
            v.append([p0.real, p0.imag]); i.append([0, 0]); o.append([0, 0])
        o[-1] = [0, 0] if ln else [c1.real - p0.real, c1.imag - p0.imag]
        v.append([p1.real, p1.imag]); i.append([0, 0] if ln else [c2.real - p1.real, c2.imag - p1.imag]); o.append([0, 0])
    if closed and len(v) > 1 and abs(v[0][0] - v[-1][0]) < 0.05 and abs(v[0][1] - v[-1][1]) < 0.05:
        i[0] = i[-1]; v.pop(); i.pop(); o.pop()
    r = lambda a: [[round(x, 3), round(y, 3)] for x, y in a]
    return sh(r(v), r(i), r(o), closed)

def d_shapes(d):
    return [segs_to_sh(list(s)) for s in parse_path(d).continuous_subpaths()]

def find(prefix):
    p = prefix.replace(' ', '')
    for d in PATHS:
        if d.replace(' ', '').startswith(p):
            return d
    raise KeyError(prefix)

def ell(cx, cy, rx, ry=None):
    return el((cx, cy), (rx * 2, (ry if ry is not None else rx) * 2))

def gfill(s, e, c0, c1):
    return {"ty": "gf", "nm": "grad", "o": st(100), "r": 1, "t": 1, "s": st(list(s)), "e": st(list(e)),
            "g": {"p": 2, "k": st([0, *c0[:3], 1, *c1[:3]])}}

# ---------- character parts ----------
PUPIL_L, PUPIL_R, PUPIL_RAD = (269.21, 281.86), (481.02, 281.86), 59.67
HL_L, HL_R, HL_RAD = (287.86, 258.74), (462.38, 258.74), 17.15
HEAD_PIV = (375, 470)
ROOT_PIV = (377, 905)
PIV_L, PIV_R = (160, 522), (590, 522)

def head_shapes():
    return [gr(d_shapes(find('M683.887 290.813C683.836')) + [fl(BLACK)], "head-line"),
            gr(d_shapes(find('M683.887 290.813C683.887 423')) + [fl(C_HEAD)], "head"),
            gr(d_shapes(find('M268.849 70.0503C262.663')) + [fl(BLACK)], "ear-L-line"),
            gr(d_shapes(find('M136.839 1.43491')) + [fl(C_HEAD)], "ear-L"),
            gr(d_shapes(find('M481.024 70.0503C487.209')) + [fl(BLACK)], "ear-R-line"),
            gr(d_shapes(find('M613.034 1.43491')) + [fl(C_HEAD)], "ear-R")]

def eye_mask():
    return gr(d_shapes(find('M249.074 149.107')) + [fl(C_MASK)], "eye-mask")

def beak():
    return gr(d_shapes(find('M421.359 341.529')) + [fl(C_BEAK)], "beak")

def star4(c, R, color):
    k = R * 0.3
    x, y = c
    pts = [[x, y - R], [x + k, y - k], [x + R, y], [x + k, y + k], [x, y + R], [x - k, y + k], [x - R, y], [x - k, y - k]]
    return gr([sh(pts), sk(color, 3), fl(color)], "star")

def pupil_group(side, look=None, extra=None, hl=True):
    """Pupil + highlight. look: dict with p, s, o (animated or static)."""
    pc, hc = (PUPIL_L, HL_L) if side == 'L' else (PUPIL_R, HL_R)
    look = look or {'p': list(pc), 's': [100, 100], 'o': 100}
    items = []
    if extra:
        items += extra
    if hl:
        items.append(gr([ell(*hc, HL_RAD), fl(C_MASK)], "highlight", o=look.get('hl_o', 100)))
    items.append(gr([ell(*pc, PUPIL_RAD), fl(C_PUPIL)], "pupil"))
    return gr(items, 'pupil-' + side, a=pc, p=look['p'], s=look['s'], o=look['o'])

def arc(side, kind, s=(100, 100), o=100, w=20, dy=0):
    """kind 'up' = happy ∩, 'down' = closed/sleepy ‿."""
    cx, cy = PUPIL_L if side == 'L' else PUPIL_R
    cy += dy
    if kind == 'up':
        pts = [[cx - 60, cy + 20], [cx, cy - 26], [cx + 60, cy + 20]]
        i, oo = [[0, 0], [-34, 0], [-8, -20]], [[8, -20], [34, 0], [0, 0]]
    else:
        pts = [[cx - 62, cy - 8], [cx, cy + 26], [cx + 62, cy - 8]]
        i, oo = [[0, 0], [-34, 0], [-8, 18]], [[8, 18], [34, 0], [0, 0]]
    return gr([sh(pts, i, oo, closed=False), sk(C_PUPIL, w)], f'{kind}-arc-{side}', a=(cx, cy), p=(cx, cy), s=s, o=o)

def brow(side, kind, p=None, r=0, o=100):
    cx, cy = PUPIL_L if side == 'L' else PUPIL_R
    f = 1 if side == 'L' else -1   # f=1: outer edge is to the left
    if kind == 'sad':      # inner end raised
        pts = [[cx - 66 * f, cy - 70], [cx + 44 * f, cy - 104]]
        i, oo = [[0, 0], [-20 * f, 2]], [[30 * f, -4], [0, 0]]
    elif kind == 'angry':  # inner end lowered
        pts = [[cx - 70 * f, cy - 112], [cx + 50 * f, cy - 70]]
        i, oo = [[0, 0], [-34 * f, -8]], [[34 * f, 8], [0, 0]]
    elif kind == 'raised':
        pts = [[cx - 60, cy - 92], [cx + 52, cy - 96]]
        i, oo = [[0, 0], [-30, -12]], [[30, -30], [0, 0]]
    else:                  # proud: gentle arch
        pts = [[cx - 54, cy - 84], [cx + 54, cy - 84]]
        i, oo = [[0, 0], [-26, -24]], [[26, -24], [0, 0]]
    a = (cx, cy - 88)
    return gr([sh(pts, i, oo, closed=False), sk(C_PUPIL, 18)], f'brow-{side}', a=a, p=p if p else a, r=r, o=o)

def rays(c, base_ang, vis, ind, N, size=2.4, color=YEL, width=15, loop=False):
    """Three short burst lines. vis: list of (start,end); loop=True keeps them visible and pulsing."""
    x, y = c
    items = []
    for d in (-38, 0, 38):
        a = math.radians(base_ang + d)
        r1, r2 = 10 * size, 26 * size
        items.append(sh([[x + r1 * math.cos(a), y + r1 * math.sin(a)], [x + r2 * math.cos(a), y + r2 * math.sin(a)]], closed=False))
    shapes = [gr(items + [sk(color, width)], "rays")]
    if loop:
        s = K([(0, [100, 100]), (N // 4, [118, 118]), (N // 2, [100, 100]), (3 * N // 4, [118, 118]), (N, [100, 100])])
        return layer('rays', ind, shapes, a=c, s=s, N=N)
    ks_s, ks_o = [(0, [0, 0], 'hold')], [(0, 0, 'hold')]
    for (a, b) in vis:
        ks_s += [(a, [30, 30], 'back'), (a + 7, [100, 100]), (b - 5, [100, 100], 'in'), (b, [60, 60], 'hold')]
        ks_o += [(a, 100, 'hold'), (b - 5, 100, 'lin'), (b, 0, 'hold')]
    ks_s.append((N, [0, 0])); ks_o.append((N, 0))
    return layer('rays', ind, shapes, a=c, s=K(ks_s), o=K(ks_o), N=N)

# ---------- body-only parts ----------
def body_shapes():
    return [gr(d_shapes(find('M83.303 826.442')) + [sk(BLACK, 1.5), fl(C_BODY)], "body")]

def cape_back_shapes():
    return [gr(d_shapes(find('M372.134 472.793C248.496 472.793 54.7242 762.917 60.5084 806.92C61.5686 814.985 73.1487 821.847 91.5988 827.655C153')) +
               [sk(BLACK, 1.5), fl(C_CAPE_D)], "cape-back")]

def belly_shapes():
    logo_f = gr(d_shapes(find('M447.677 631.945')) + [gfill((375.4, 602.4), (375.4, 754.2), hx('#1C6BFC'), hx('#082EA2'))], "logo-F")
    logo_j = gr(d_shapes(find('M384.283 733.025')) + [gfill((416.8, 690.7), (416.8, 770.1), hx('#FADF01'), hx('#DA9400'))], "logo-J")
    white = gr(d_shapes(find('M375.864 841.228')) + [fl(WHITE)], "belly")
    inner = gr(d_shapes(find('M375.864 878.519')) + [fl(C_INNER)], "inner-body")
    return [logo_j, logo_f, white, inner]

def belly_mask():
    shp = segs_to_sh(list(parse_path(find('M91.5989 827.655C153.68 847.197 164')).continuous_subpaths()[0]))
    return [{"inv": False, "mode": "a", "pt": shp["ks"], "o": st(100), "x": st(0), "nm": "cape-opening"}]

def cape_edge_shapes():
    return [gr(d_shapes(find('M372.134 472.793C248.496 472.793 54.7242 762.917 60.5084 806.92C61.5686 814.985 73.1487 821.847 91.5988 827.655C129')) +
               [sk(BLACK, 1.5), fl(C_CAPE)], "cape-edges")]

def collar_shapes():
    return [gr(d_shapes(find('M309.485 500.626')) + [sk(BLACK, 6), fl(C_CAPE)], "knot"),
            gr(d_shapes(find('M115.573 474.688')) + [sk(BLACK, 6), fl(C_CAPE)], "collar")]

def wing_shapes(side):
    d = find('M15.6404 762.355') if side == 'L' else find('M734.702 762.355')
    return [gr(d_shapes(d) + [sk(BLACK, 1.5), fl(C_BODY)], "wing")]

def foot_shapes(side):
    if side == 'L':
        outline, mid = find('M214.766 826.311'), find('M276.002 832.231C296')
        toes = [(319.927, 876.307, 29.8328, 29.1641), (214.766, 863.808, 42.5117, 37.4967)]
    else:
        outline, mid = find('M538.452 826.311'), find('M468.448 836.148C450')
        toes = [(433.292, 876.307, 29.8328, 29.1641), (538.452, 863.808, 42.5117, 37.4967)]
    fills = [gr([ell(*t), fl(C_FOOT)], "toe") for t in toes] + [gr(d_shapes(mid) + [fl(C_FOOT)], "toe-mid")]
    return fills + [gr(d_shapes(outline) + [sk(BLACK, 9), fl(BLACK)], "foot-line")]

# ---------- fx ----------
def motion_lines(vis, ind, N):
    items = []
    for x, d in ((170, -1), (136, -1), (588, 1), (622, 1)):
        items.append(sh([[x, 858], [x + 13 * d, 906]], i=[[0, 0], [-9 * d, -9]], o=[[9 * d, 13], [0, 0]], closed=False))
    ko = [(0, 0, 'hold')]
    for (a, b) in vis:
        ko += [(a, 100, 'hold'), (b - 4, 100, 'lin'), (b, 0, 'hold')]
    ko.append((N, 0))
    return layer('motion-lines', ind, [gr(items + [sk(C_BODY, 11)], "lines")], a=(377, 880), o=K(ko), N=N)

def waves(vis, ind, N, c):
    items = []
    for dx, r in ((100, 36), (135, 60)):
        x = c[0] + dx
        items.append(sh([[x, c[1] - r], [x + 18, c[1]], [x, c[1] + r]],
                        i=[[0, 0], [0, -r * 0.6], [12, -12]], o=[[12, 12], [0, r * 0.6], [0, 0]], closed=False))
    a, b = vis
    s = [(0, [80, 80], 'hold'), (a, [80, 80], 'out')]
    t = a
    while t + 8 < b:
        s += [(t + 4, [112, 112]), (t + 8, [92, 92])]
        t += 8
    s += [(b, [100, 100], 'hold'), (N, [100, 100])]
    o = [(0, 0, 'hold'), (a, 0, 'out'), (a + 4, 100, 'hold'), (b - 6, 100, 'lin'), (b, 0, 'hold'), (N, 0)]
    return layer('ring-waves', ind, [gr(items + [sk(YEL, 12)], "waves")], a=c, s=K(s), o=K(o), N=N)

def confetti(t0, origin, ind0, N, count=16, spread=1.0):
    out = []
    for k in range(count):
        ang = -172 + k * (164 / (count - 1)) + (7 if k % 2 else -5)
        dist = (380 + (k * 53 % 160)) * spread
        a = math.radians(ang)
        tx, ty = origin[0] + dist * math.cos(a), origin[1] + dist * math.sin(a)
        col = CONF_COLORS[k % len(CONF_COLORS)]
        w, h = (24, 42) if k % 3 else (27, 27)
        s0 = t0 + (k % 4)
        p = K([(0, list(origin), 'hold'), (s0, list(origin), 'out'), (s0 + 18, [tx, ty], 'in'),
               (s0 + 40, [tx + 15 * math.cos(a), ty + 90], 'lin'), (N, [tx + 15 * math.cos(a), ty + 90])])
        r = K([(s0, 0, 'lin'), (s0 + 40, 540 * (1 if k % 2 else -1))])
        o = K([(0, 0, 'hold'), (s0, 100, 'hold'), (s0 + 28, 100, 'lin'), (s0 + 40, 0, 'hold'), (N, 0)])
        s = K([(0, [0, 0], 'hold'), (s0, [40, 40], 'out'), (s0 + 8, [100, 100]), (N, [100, 100])])
        out.append(layer('confetti', ind0 + k, [gr([rc((0, 0), (w, h), 6), fl(col)], "piece")], a=(0, 0), p=p, r=r, o=o, s=s, N=N))
    return out

# ---------- props ----------
RAISE, GRIP_LEN, PROP_SCALE = -100, 250, 225

def tip_angle():
    return math.degrees(math.atan2(762.4 - PIV_R[1], 734.7 - PIV_R[0]))

def _grip():
    a0, a1 = math.radians(tip_angle()), math.radians(tip_angle() + RAISE)
    rest = [round(PIV_R[0] + GRIP_LEN * math.cos(a0), 2), round(PIV_R[1] + GRIP_LEN * math.sin(a0), 2)]
    world = (PIV_R[0] + GRIP_LEN * math.cos(a1), PIV_R[1] + GRIP_LEN * math.sin(a1))
    return rest, world

GRIP_REST, GRIP_WORLD = _grip()

def prop_world(dx, dy):
    return (GRIP_WORLD[0] + dx * PROP_SCALE / 100, GRIP_WORLD[1] + dy * PROP_SCALE / 100)

def prop_layer(kind, g, N, parent):
    shapes, a = (magnifier_shapes(), (420, 238)) if kind == 'magnifier' else (bell_shapes(g('bell_r', 0)), (420, 250))
    return layer('prop', 11, [gr(shapes, kind, a=a, p=a, s=(PROP_SCALE, PROP_SCALE))],
                 a=a, p=GRIP_REST, r=-RAISE, s=g('prop_s', [0, 0]), parent=parent, N=N)

# ---------- full-body assembly ----------
def body_face_shapes(spec, N):
    parts = []
    for side, pc in (('L', PUPIL_L), ('R', PUPIL_R)):
        closed = spec.get('closed_' + side, spec.get('closed', []))
        look, happy = eye_anim(closed, pc, spec.get('look'), N)
        parts += [arc(side, 'up', s=happy['s'], o=happy['o']), pupil_group(side, look)]
    return [beak()] + parts + [eye_mask()]

def build_body(name, N, spec, face=None, fx=None, stage=((377, 905), (360, 674), 56), lids=None):
    g = lambda k, d: K(spec[k]) if k in spec else d
    ROOT, BODY, HEAD, FACE, COLLAR, WL, WR, FL_, FR_, SHAD, PROP, BELLY, CBACK, CEDGE = range(1, 15)
    layers, ind = list(fx or []), 40
    for sp in spec.get('sparkles', []):
        layers.append(rays(sp['c'], sp.get('ang', -60), sp['vis'], ind, N)); ind += 1
    if 'waves' in spec:
        layers.append(waves(spec['waves'], ind, N, prop_world(0, -64))); ind += 1
    if 'prop' in spec:
        layers.append(prop_layer(spec['prop'], g, N, WR))
    layers.append(layer('foot-L', FL_, foot_shapes('L'), a=(262, 866), p=g('footL', [262, 866]), parent=ROOT, N=N))
    layers.append(layer('foot-R', FR_, foot_shapes('R'), a=(492, 866), p=g('footR', [492, 866]), parent=ROOT, N=N))
    layers.append(layer('collar', COLLAR, collar_shapes(), a=(372, 500), parent=ROOT, N=N))
    layers.append(layer('wing-R', WR, wing_shapes('R'), a=PIV_R, r=g('wingR', 0), s=g('wingR_s', [100, 100]), parent=ROOT, N=N))
    layers.append(layer('wing-L', WL, wing_shapes('L'), a=PIV_L, r=g('wingL', 0), s=g('wingL_s', [100, 100]), parent=ROOT, N=N))
    layers.append(layer('cape', CEDGE, cape_edge_shapes(), a=(372, 650), parent=ROOT, N=N))
    bl = layer('belly', BELLY, belly_shapes(), a=(377, 660), parent=ROOT, N=N)
    bl['hasMask'] = True; bl['masksProperties'] = belly_mask()
    layers.append(bl)
    layers.append(layer('cape-back', CBACK, cape_back_shapes(), a=(372, 650), parent=ROOT, N=N))
    layers.append(layer('face', FACE, (face + [beak(), eye_mask()]) if face is not None else body_face_shapes(spec, N), a=(375, 280), parent=HEAD, N=N))
    layers.append(layer('head', HEAD, head_shapes(), a=HEAD_PIV, p=g('head_p', list(HEAD_PIV)), r=g('head_r', 0), parent=ROOT, N=N))
    layers.append(layer('body', BODY, body_shapes(), a=(377, 650), parent=ROOT, N=N))
    if 'confetti' in spec:
        layers += confetti(spec['confetti'], (377, 300), 60, N)
    if 'lines' in spec:
        layers.append(motion_lines(spec['lines'], ind, N)); ind += 1
    layers.append(layer('shadow', SHAD, [gr([el((377, 903), (620, 52)), fl([0.05, 0.08, 0.25, 1], 14)], "shadow")],
                        a=(377, 903), s=g('shadow', [100, 100]), N=N))
    layers.append(null('rig', ROOT, a=ROOT_PIV, p=g('root_p', list(ROOT_PIV)), s=g('root_s', [100, 100]), r=g('root_r', 0), N=N))
    for Lr in layers:
        Lr.setdefault('parent', 99)
    layers.append(null('stage', 99, a=stage[0], p=stage[1], s=(stage[2], stage[2]), N=N))
    return comp(name, N, layers)

def comp(name, N, layers):
    return {"v": "5.12.2", "fr": FR, "ip": 0, "op": N, "w": CW, "h": CH, "nm": name, "ddd": 0,
            "assets": [], "layers": layers, "markers": []}

P0 = list(ROOT_PIV)
def up(dy): return [ROOT_PIV[0], ROOT_PIV[1] - dy]
def LK(x, y): return (round(x * 2.25, 1), round(y * 2.25, 1))

BODY_ANIMS = {}
N = 90
BODY_ANIMS['idle-blink'] = build_body('Idle Blink', N, {
    'root_s': [(0, [100, 100]), (10, [104, 95]), (15, [96, 105], 'out'), (22, [99, 101]), (27, [105, 95], 'out'),
               (33, [100, 100]), (60, [101, 99]), (90, [100, 100])],
    'root_p': [(0, P0), (13, P0, 'out'), (20, up(45), 'in'), (27, P0), (90, P0)],
    'shadow': [(0, [100, 100]), (13, [100, 100], 'out'), (20, [82, 82], 'in'), (27, [100, 100]), (90, [100, 100])],
    'head_r': [(0, 0), (40, -3), (70, 3), (90, 0)],
    'wingL': [(0, 0), (12, 0, 'out'), (19, 12), (27, 0), (90, 0)],
    'wingR': [(0, 0), (12, 0, 'out'), (19, -12), (27, 0), (90, 0)],
    'look': [(0, (0, 0)), (40, (0, 0)), (46, LK(-8, 1)), (60, LK(-8, 1)), (68, LK(8, 1)), (80, LK(8, 1)), (88, (0, 0)), (90, (0, 0))],
    'closed': [(62, 66)],
    'lines': [(25, 34)],
    'sparkles': [{'c': (720, 60), 'ang': -50, 'vis': [(20, 44)]}],
})
N = 32
BODY_ANIMS['walking'] = build_body('Walking', N, {
    'root_p': [(0, P0), (8, up(18)), (16, P0), (24, up(18)), (32, P0)],
    'root_r': [(0, -4), (16, 4), (32, -4)],
    'head_r': [(0, 2), (16, -2), (32, 2)],
    'footR': [(0, [492, 836]), (7, [492, 866]), (25, [492, 866]), (32, [492, 836])],
    'footL': [(0, [262, 866]), (9, [262, 866]), (16, [262, 836]), (23, [262, 866]), (32, [262, 866])],
    'wingL': [(0, 8), (16, -4), (32, 8)],
    'wingR': [(0, 4), (16, -8), (32, 4)],
    'shadow': [(0, [100, 100]), (8, [95, 100]), (16, [100, 100]), (24, [95, 100]), (32, [100, 100])],
})
N = 100
_m = prop_world(0, -72)
BODY_ANIMS['search-analyze'] = build_body('Search / Analyze', N, {
    'prop': 'magnifier',
    'wingR': [(0, 0), (10, 0, 'out'), (22, RAISE), (36, RAISE + 7), (50, RAISE - 5), (64, RAISE + 5), (78, RAISE),
              (82, RAISE), (94, 0), (100, 0)],
    'prop_s': [(0, [0, 0], 'hold'), (12, [0, 0], 'back'), (26, [100, 100]), (80, [100, 100], 'in'), (90, [0, 0], 'hold'), (100, [0, 0])],
    'look': [(0, (0, 0)), (16, (0, 0)), (24, LK(10, -6)), (78, LK(10, -6)), (86, (0, 0)), (100, (0, 0))],
    'closed_L': [(46, 58)],
    'head_r': [(0, 0), (20, 0), (30, 5), (76, 5), (86, 0), (100, 0)],
    'root_s': [(0, [100, 100]), (50, [101, 99]), (100, [100, 100])],
    'sparkles': [{'c': (_m[0] + 120, _m[1] - 105), 'ang': -50, 'vis': [(28, 44), (60, 76)]}],
})
N = 96
_b = prop_world(0, -64)
BODY_ANIMS['price-alert'] = build_body('Price Alert', N, {
    'prop': 'bell',
    'wingR': [(0, 0), (8, 0, 'out'), (20, RAISE), (76, RAISE), (88, 0), (96, 0)],
    'prop_s': [(0, [0, 0], 'hold'), (10, [0, 0], 'back'), (22, [100, 100]), (76, [100, 100], 'in'), (84, [0, 0], 'hold'), (96, [0, 0])],
    'bell_r': [(0, 0), (22, 0), (28, 22), (34, -22), (40, 20), (46, -20), (52, 14), (58, -10), (64, 5), (70, 0), (96, 0)],
    'waves': (26, 64),
    'closed': [(36, 54)],
    'look': [(0, (0, 0)), (14, (0, 0)), (22, LK(9, -5)), (74, LK(9, -5)), (84, (0, 0)), (96, (0, 0))],
    'root_r': [(0, 0), (24, 0), (28, 2), (32, -2), (36, 2), (40, -2), (44, 0), (96, 0)],
    'sparkles': [{'c': (_b[0] + 105, _b[1] - 135), 'ang': -50, 'vis': [(22, 40)]}],
})
N = 80
flapL = [(0, 0), (8, 0, 'out'), (16, 95), (20, 78), (24, 98), (28, 80), (32, 95), (40, 80), (48, 96), (56, 82), (62, 92), (72, 0), (80, 0)]
BODY_ANIMS['celebrate'] = build_body('Celebrate / Deal Found', N, {
    'root_s': [(0, [100, 100]), (8, [108, 90]), (13, [95, 106], 'out'), (24, [98, 103]), (32, [110, 90], 'out'),
               (40, [97, 103]), (46, [100, 100]), (50, [104, 95]), (54, [97, 104]), (62, [106, 94]), (68, [100, 100]), (80, [100, 100])],
    'root_p': [(0, P0), (10, P0, 'out'), (22, up(105), 'in'), (32, P0), (52, P0, 'out'), (57, up(50), 'in'), (62, P0), (80, P0)],
    'shadow': [(0, [100, 100]), (10, [100, 100], 'out'), (22, [62, 62], 'in'), (32, [100, 100]), (52, [100, 100], 'out'),
               (57, [84, 84], 'in'), (62, [100, 100]), (80, [100, 100])],
    'wingL': flapL,
    'wingR': [(t, -v, *e) for (t, v, *e) in flapL],
    'closed': [(8, 70)],
    'head_r': [(0, 0), (22, -4), (40, 4), (52, -3), (68, 0), (80, 0)],
    'confetti': 14,
    'lines': [(30, 42), (61, 69)],
    'sparkles': [{'c': (745, 45), 'ang': -50, 'vis': [(14, 36)]}, {'c': (10, 45), 'ang': -130, 'vis': [(18, 40)]}],
})


if __name__ == '__main__':
    out = os.path.join(HERE, 'json')
    for f in os.listdir(out):
        if not f.startswith('owl-expr-'):
            os.remove(os.path.join(out, f))
    for k, v in BODY_ANIMS.items():
        json.dump(v, open(os.path.join(out, f'owl-{k}.json'), 'w'), separators=(',', ':'))
        print(k, os.path.getsize(os.path.join(out, f'owl-{k}.json')) // 1024, 'KB')
