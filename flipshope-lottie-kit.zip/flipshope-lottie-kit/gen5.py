"""Owl Lottie rig v5: v4 artwork + soft 3D shading, bendable wings, head-turn parallax, Fluent Emoji props."""
import json, math, os, copy
from gen import st, K, sh, fl, sk, tr, gr, layer, null, el, rc, hx, YEL, YEL_D, WHITE, CONF_COLORS, EASES
from gen4 import (d_shapes, find, ell, segs_to_sh, rays, motion_lines, confetti, arc, brow, star4, eye_anim,
                  PUPIL_L, PUPIL_R, PUPIL_RAD, HL_L, HL_R, HL_RAD, HEAD_PIV, ROOT_PIV, PIV_L, PIV_R,
                  C_BODY, C_HEAD, C_INNER, C_MASK, C_PUPIL, C_BEAK, C_CAPE_D, C_CAPE, C_FOOT, BLACK, belly_mask, comp)
from assets_lib import icon

HERE = os.path.dirname(os.path.abspath(__file__))
NAVY = hx('#001A5E')
GOLD_D = hx('#9C6A00')

# ---------- gradient helpers ----------
def grad(kind, s, e, colors, alphas=None):
    k = []
    for off, c in colors:
        k += [off, c[0], c[1], c[2]]
    for off, a in (alphas or []):
        k += [off, a]
    g = {"ty": "gf", "nm": "shade", "o": st(100), "r": 1, "t": 1 if kind == 'linear' else 2,
         "s": st(list(s)), "e": st(list(e)), "g": {"p": len(colors), "k": st(k)}}
    if kind != 'linear':
        g["h"] = st(0); g["a"] = st(0)
    return g

def inner_shadow(paths, c, r_end, color=NAVY, start=0.55, strength=0.38, nm="inner-shadow"):
    return gr(paths + [grad('radial', c, (c[0] + r_end, c[1]), [(0, color), (1, color)],
                            [(0, 0), (start, 0), (1, strength)])], nm)

def highlight(paths, c, r_end, strength=0.25, nm="highlight"):
    return gr(paths + [grad('radial', c, (c[0] + r_end, c[1]), [(0, WHITE), (1, WHITE)], [(0, strength), (1, 0)])], nm)

def vshade(paths, y0, y1, color, a0, a1, nm="v-shade", x=375):
    return gr(paths + [grad('linear', (x, y0), (x, y1), [(0, color), (1, color)], [(0, a0), (1, a1)])], nm)

# ---------- shaded parts ----------
HEAD_D = find('M683.887 290.813C683.887 423')
EAR_L_D, EAR_R_D = find('M136.839 1.43491'), find('M613.034 1.43491')

def head_shapes():
    return [
        highlight(d_shapes(HEAD_D), (250, 130), 260, 0.22, "head-shine"),
        inner_shadow(d_shapes(HEAD_D), (330, 210), 430, start=0.5, strength=0.42, nm="head-shade"),
        gr(d_shapes(find('M683.887 290.813C683.836')) + [fl(BLACK)], "head-line"),
        gr(d_shapes(HEAD_D) + [fl(C_HEAD)], "head"),
        vshade(d_shapes(EAR_L_D), 20, 170, NAVY, 0.0, 0.35, "ear-L-shade", 180),
        gr(d_shapes(find('M268.849 70.0503C262.663')) + [fl(BLACK)], "ear-L-line"),
        gr(d_shapes(EAR_L_D) + [fl(C_HEAD)], "ear-L"),
        vshade(d_shapes(EAR_R_D), 20, 170, NAVY, 0.0, 0.35, "ear-R-shade", 570),
        gr(d_shapes(find('M481.024 70.0503C487.209')) + [fl(BLACK)], "ear-R-line"),
        gr(d_shapes(EAR_R_D) + [fl(C_HEAD)], "ear-R")]

MASK_D = find('M249.074 149.107')
BEAK_D = find('M421.359 341.529')

def eye_mask():
    return gr([vshade(d_shapes(MASK_D), 150, 225, NAVY, 0.16, 0.0, "brow-shadow"),
               inner_shadow(d_shapes(MASK_D), (373, 268), 300, color=hx('#5D78C2'), start=0.62, strength=0.5, nm="eye-rim"),
               gr(d_shapes(MASK_D) + [fl(C_MASK)], "eye-white")], "eye-mask")

def beak():
    return gr([gr([ell(362, 318, 13, 9), fl(WHITE, 60)], "beak-shine"),
               vshade(d_shapes(BEAK_D), 300, 410, hx('#D98A00'), 0.0, 0.55, "beak-shade"),
               gr(d_shapes(BEAK_D) + [fl(C_BEAK)], "beak-fill")], "beak")

def pupil_group(side, look=None, extra=None, hl=True):
    pc, hc = (PUPIL_L, HL_L) if side == 'L' else (PUPIL_R, HL_R)
    look = look or {'p': list(pc), 's': [100, 100], 'o': 100}
    items = list(extra or [])
    if hl:
        items.append(gr([ell(pc[0] - (hc[0] - pc[0]) * 0.9, pc[1] + 30, 7), fl(C_MASK, 70)], "highlight-2"))
        items.append(gr([ell(*hc, HL_RAD), fl(C_MASK)], "highlight"))
    items.append(gr([ell(*pc, PUPIL_RAD), grad('linear', (pc[0], pc[1] - 60), (pc[0], pc[1] + 60),
                                                 [(0, C_PUPIL), (0.55, C_PUPIL), (1, hx('#1D3A86'))])], "pupil"))
    return gr(items, 'pupil-' + side, a=pc, p=look['p'], s=look['s'], o=look['o'])

BODY_D = find('M83.303 826.442')

def body_shapes():
    return [inner_shadow(d_shapes(BODY_D), (330, 580), 470, start=0.45, strength=0.45, nm="body-shade"),
            gr(d_shapes(BODY_D) + [sk(BLACK, 1.5), fl(C_BODY)], "body")]

CB_D = find('M372.134 472.793C248.496 472.793 54.7242 762.917 60.5084 806.92C61.5686 814.985 73.1487 821.847 91.5988 827.655C153')
CE_D = find('M372.134 472.793C248.496 472.793 54.7242 762.917 60.5084 806.92C61.5686 814.985 73.1487 821.847 91.5988 827.655C129')

def cape_back_shapes():
    return [vshade(d_shapes(CB_D), 480, 860, GOLD_D, 0.1, 0.45, "cape-back-shade"),
            gr(d_shapes(CB_D) + [sk(BLACK, 1.5), fl(C_CAPE_D)], "cape-back")]

def cape_edge_shapes():
    return [highlight(d_shapes(CE_D), (300, 520), 260, 0.35, "cape-shine"),
            vshade(d_shapes(CE_D), 520, 860, GOLD_D, 0.0, 0.35, "cape-shade"),
            gr(d_shapes(CE_D) + [sk(BLACK, 1.5), fl(C_CAPE)], "cape-edges")]

def gfill(s, e, c0, c1):
    return grad('linear', s, e, [(0, c0), (1, c1)])

def belly_shapes():
    W_D = find('M375.864 841.228')
    logo_f = gr(d_shapes(find('M447.677 631.945')) + [gfill((374.6, 602.4), (374.6, 754.2), hx('#1C6BFC'), hx('#082EA2'))], "logo-F")
    logo_j = gr(d_shapes(find('M384.283 733.025')) + [gfill((416, 690.7), (416, 770.1), hx('#FADF01'), hx('#DA9400'))], "logo-J")
    return [
        gr([ell(375, 540, 230, 48), grad('radial', (375, 540), (605, 540), [(0, NAVY), (1, NAVY)], [(0, 0.35), (1, 0)])], "collar-cast"),
        logo_j, logo_f,
        inner_shadow(d_shapes(W_D), (360, 640), 240, color=hx('#6F86C9'), start=0.6, strength=0.45, nm="belly-shade"),
        gr(d_shapes(W_D) + [fl(WHITE)], "belly"),
        inner_shadow(d_shapes(find('M375.864 878.519')), (375, 640), 300, start=0.5, strength=0.4, nm="inner-body-shade"),
        gr(d_shapes(find('M375.864 878.519')) + [fl(C_INNER)], "inner-body")]

def collar_shapes():
    KN, CO = find('M309.485 500.626'), find('M115.573 474.688')
    def shaded(d, nm, y0, y1):
        return [gr(d_shapes(d) + [grad('linear', (375, y0), (375, y1), [(0, WHITE), (0.45, WHITE), (0.5, GOLD_D), (1, GOLD_D)],
                                       [(0, 0.45), (0.45, 0), (0.55, 0), (1, 0.42)])], nm + "-shade"),
                gr(d_shapes(d) + [sk(BLACK, 6), fl(C_CAPE)], nm)]
    return shaded(KN, "knot", 466, 543) + shaded(CO, "collar", 446, 531)

def neck_shadow_shapes():
    return [gr([ell(375, 532, 290, 52), grad('radial', (375, 532), (665, 532), [(0, NAVY), (1, NAVY)], [(0, 0.42), (1, 0)])], "head-cast")]

# ---------- bendable wings ----------
WING_D = {'L': find('M15.6404 762.355'), 'R': find('M734.702 762.355')}
TIP = {'L': (15.64, 762.36), 'R': (734.7, 762.36)}
PIV = {'L': PIV_L, 'R': PIV_R}

def _wing_base(side):
    return d_shapes(WING_D[side])[0]['ks']['k']

def bend_shape(side, curl):
    """Rotate each vertex about the shoulder by curl * w(t)^1.6, t = distance along shoulder->tip axis."""
    base = _wing_base(side)
    px, py = PIV[side]
    tx, ty = TIP[side]
    L = math.hypot(tx - px, ty - py)
    ux, uy = (tx - px) / L, (ty - py) / L
    def ang(x, y):
        t = max(0.0, min(1.0, ((x - px) * ux + (y - py) * uy) / L))
        return math.radians(curl * t ** 1.6)
    def rot(x, y, a, cx=px, cy=py):
        c, s = math.cos(a), math.sin(a)
        return [round(cx + (x - cx) * c - (y - cy) * s, 3), round(cy + (x - cx) * s + (y - cy) * c, 3)]
    v, i, o = [], [], []
    for (x, y), (ix, iy), (ox, oy) in zip(base['v'], base['i'], base['o']):
        a = ang(x, y)
        nv = rot(x, y, a)
        v.append(nv)
        i.append([round(a_, 3) for a_ in rot(ix, iy, a, 0, 0)])
        o.append([round(a_, 3) for a_ in rot(ox, oy, a, 0, 0)])
    return {"v": v, "i": i, "o": o, "c": True}

def bent_point(side, pt, curl):
    px, py = PIV[side]
    tx, ty = TIP[side]
    L = math.hypot(tx - px, ty - py)
    ux, uy = (tx - px) / L, (ty - py) / L
    t = max(0.0, min(1.0, ((pt[0] - px) * ux + (pt[1] - py) * uy) / L))
    a = math.radians(curl * t ** 1.6)
    c, s = math.cos(a), math.sin(a)
    return (px + (pt[0] - px) * c - (pt[1] - py) * s, py + (pt[0] - px) * s + (pt[1] - py) * c), math.degrees(a)

def wing_path(side, curl_keys):
    if not curl_keys:
        return {"ty": "sh", "d": 1, "nm": "wing-path", "ks": st(bend_shape(side, 0))}
    ks = []
    for n, f in enumerate(curl_keys):
        t, v = f[0], f[1]
        e = f[2] if len(f) > 2 else 'ease'
        k = {"t": t, "s": [bend_shape(side, v)]}
        if n < len(curl_keys) - 1:
            if e == 'hold':
                k["h"] = 1
            else:
                ox, oy, ix, iy = EASES[e]
                k["o"] = {"x": [ox], "y": [oy]}; k["i"] = {"x": [ix], "y": [iy]}
        ks.append(k)
    return {"ty": "sh", "d": 1, "nm": "wing-path", "ks": {"a": 1, "k": ks}}

def wing_shapes(side, curl_keys=None):
    px, py = PIV[side]
    tx, ty = TIP[side]
    shade = grad('linear', (px, py), (tx, ty), [(0, NAVY), (1, NAVY)], [(0, 0.0), (0.45, 0.05), (1, 0.42)])
    shine = grad('radial', (px + (tx - px) * 0.25, py + (ty - py) * 0.25), (px + (tx - px) * 0.25 + 120, py + (ty - py) * 0.25),
                 [(0, WHITE), (1, WHITE)], [(0, 0.2), (1, 0)])
    return [gr([wing_path(side, curl_keys), sk(BLACK, 1.5), shine, shade, fl(C_BODY)], "wing")]

# ---------- feet & ground ----------
def foot_shapes(side):
    if side == 'L':
        outline, mid = find('M214.766 826.311'), find('M276.002 832.231C296')
        toes = [(319.927, 876.307, 29.8328, 29.1641), (214.766, 863.808, 42.5117, 37.4967)]
    else:
        outline, mid = find('M538.452 826.311'), find('M468.448 836.148C450')
        toes = [(433.292, 876.307, 29.8328, 29.1641), (538.452, 863.808, 42.5117, 37.4967)]
    def toe_fill(paths):
        return gr(paths + [grad('linear', (0, 830), (0, 910), [(0, hx('#FFE45C')), (0.5, C_FOOT), (1, hx('#E9A800'))])], "toe")
    fills = [toe_fill([ell(*t)]) for t in toes] + [toe_fill(d_shapes(mid))]
    return fills + [gr(d_shapes(outline) + [sk(BLACK, 9), fl(BLACK)], "foot-line")]

def ground_shadow():
    return [gr([el((377, 903), (640, 56)), grad('radial', (377, 903), (697, 903), [(0, NAVY), (1, NAVY)], [(0, 0.3), (0.7, 0.12), (1, 0)])], "shadow")]

# ---------- props (Fluent Emoji, MIT) ----------
# name: (icon, size, grip point in icon units, base rotation, flipX, recolor)
DROP_TRIPOD = {r'<path fill="#7167a4"[^>]*/>': ''}
YELLOWIFY = {'#f8312f': '#FFC61A'}
PROPS = {
    'magnifier': ('magnifying-glass-tilted-right', 300, (6.5, 26.5), 35, False, None),
    'bell':      ('bell', 210, (16, 2.5), 0, False, None),
    'megaphone': ('megaphone', 290, (15.5, 23.5), -12, False, None),
    'star':      ('glowing-star', 250, (16, 27), 0, False, None),
    'telescope': ('telescope', 360, (29, 13.5), 0, True, DROP_TRIPOD),
}

def prop_group(kind, rot_keys=None):
    name, size, grip, base_rot, flip, recolor = PROPS[kind]
    g = icon(name, (0, 0), size, rot=0, recolor=recolor, anchor=grip)
    if flip:
        sc = g['it'][-1]['s']['k']
        g['it'][-1]['s']['k'] = [-sc[0], sc[1]]
    r = K(rot_keys) if rot_keys else base_rot
    return gr([g], kind + '-pivot', r=r)

def held_prop(kind, raise_deg, curl, grip_len, g, N, parent, scale_key='prop_s', rot_key='prop_r', tilt=0):
    """Prop attached to the right wing tip at hold pose (wing rotated raise_deg, bent curl)."""
    px, py = PIV['R']
    tx, ty = TIP['R']
    L = math.hypot(tx - px, ty - py)
    gp = (px + (tx - px) * grip_len / L, py + (ty - py) * grip_len / L)
    pt, local_ang = bent_point('R', gp, curl)
    rot = g(rot_key, None) if rot_key else None
    shapes = [prop_group(kind, rot_keys=None)]
    if rot is not None:
        shapes = [gr(shapes, 'prop-anim', r=rot)]
    return layer('prop', 11, shapes, a=(0, 0), p=[round(pt[0], 2), round(pt[1], 2)],
                 r=-(raise_deg + local_ang) + tilt, s=g(scale_key, [0, 0]), parent=parent, N=N)

def free_icon(name, c, size, ind, N, s=None, r=None, p=None, o=None, recolor=None, nm=None):
    return layer(nm or name, ind, [icon(name, (0, 0), size, recolor=recolor)], a=(0, 0), p=p if p is not None else list(c),
                 s=s if s is not None else [100, 100], r=r if r is not None else 0, o=o if o is not None else 100, N=N)

def pop_keys(t0, t1=None, N=None, hold=100):
    ks = [(0, [0, 0], 'hold'), (t0, [0, 0], 'back'), (t0 + 12, [hold, hold])]
    if t1 is not None:
        ks += [(t1 - 8, [hold, hold], 'in'), (t1, [0, 0], 'hold')]
    ks.append((N, [hold, hold] if t1 is None else [0, 0]))
    return K(ks)

# ---------- assembly ----------
def body_face_shapes(spec, N):
    parts = []
    for side in ('L', 'R'):
        closed = spec.get('closed_' + side, spec.get('closed', []))
        pc = PUPIL_L if side == 'L' else PUPIL_R
        look, happy = eye_anim(closed, pc, spec.get('look'), N)
        parts += [arc(side, 'up', s=happy['s'], o=happy['o']), pupil_group(side, look)]
    return [beak()] + parts + [eye_mask()]

def build(name, N, spec, face=None, fx=None, front=None, stage=((377, 905), (360, 674), 56)):
    """front: layers drawn above the whole body (e.g. a box being held)."""
    g = lambda k, d: K(spec[k]) if k in spec else d
    ROOT, BODY, HEAD, FACE, COLLAR, WL, WR, FL_, FR_, SHAD, PROP, BELLY, CBACK, CEDGE, NECK = range(1, 16)
    layers, ind = list(fx or []), 40
    for sp in spec.get('sparkles', []):
        layers.append(rays(sp['c'], sp.get('ang', -60), sp['vis'], ind, N)); ind += 1
    for extra in spec.get('fx_layers', []):
        layers.append(extra)
    if 'prop' in spec:
        pr = spec['prop']
        layers.append(held_prop(pr['kind'], pr['raise'], pr.get('curl', 0), pr.get('grip', 250), g, N, WR, tilt=pr.get('tilt', 0)))
    face_layer = layer('face', FACE, (face + [beak(), eye_mask()]) if face is not None else body_face_shapes(spec, N),
                       a=(375, 280), p=g('face_p', [375, 280]), parent=HEAD, N=N)
    if spec.get('prop_over_face') is False:
        layers.insert(len(layers), face_layer)
    layers += list(front or [])
    layers.append(layer('foot-L', FL_, foot_shapes('L'), a=(262, 866), p=g('footL', [262, 866]), parent=ROOT, N=N))
    layers.append(layer('foot-R', FR_, foot_shapes('R'), a=(492, 866), p=g('footR', [492, 866]), parent=ROOT, N=N))
    layers.append(layer('collar', COLLAR, collar_shapes(), a=(372, 500), parent=ROOT, N=N))
    layers.append(layer('wing-R', WR, wing_shapes('R', spec.get('wingR_curl')), a=PIV_R, r=g('wingR', 0), s=g('wingR_s', [100, 100]), parent=ROOT, N=N))
    layers.append(layer('wing-L', WL, wing_shapes('L', spec.get('wingL_curl')), a=PIV_L, r=g('wingL', 0), s=g('wingL_s', [100, 100]), parent=ROOT, N=N))
    layers.append(layer('neck-shadow', NECK, neck_shadow_shapes(), a=(375, 470), parent=HEAD, N=N))
    layers.append(layer('cape', CEDGE, cape_edge_shapes(), a=(372, 650), parent=ROOT, N=N))
    bl = layer('belly', BELLY, belly_shapes(), a=(377, 660), parent=ROOT, N=N)
    bl['hasMask'] = True; bl['masksProperties'] = belly_mask()
    layers.append(bl)
    layers.append(layer('cape-back', CBACK, cape_back_shapes(), a=(372, 650), parent=ROOT, N=N))
    if spec.get('prop_over_face') is not False:
        layers.append(face_layer)
    layers.append(layer('head', HEAD, head_shapes(), a=HEAD_PIV, p=g('head_p', list(HEAD_PIV)), r=g('head_r', 0), parent=ROOT, N=N))
    layers.append(layer('body', BODY, body_shapes(), a=(377, 650), parent=ROOT, N=N))
    if 'confetti' in spec:
        layers += confetti(spec['confetti'], (377, 300), 60, N)
    if 'lines' in spec:
        layers.append(motion_lines(spec['lines'], ind, N)); ind += 1
    layers.append(layer('shadow', SHAD, ground_shadow(), a=(377, 903), s=g('shadow', [100, 100]), N=N))
    layers.append(null('rig', ROOT, a=ROOT_PIV, p=g('root_p', list(ROOT_PIV)), s=g('root_s', [100, 100]), r=g('root_r', 0), N=N))
    for Lr in layers:
        Lr.setdefault('parent', 99)
    layers.append(null('stage', 99, a=stage[0], p=stage[1], s=(stage[2], stage[2]), N=N))
    return comp(name, N, layers)
