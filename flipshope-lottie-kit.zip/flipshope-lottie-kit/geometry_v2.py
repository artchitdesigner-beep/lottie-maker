# ---------- character geometry (v2, matched to the turnaround sheet) ----------
from svgpathtools import parse_path, Line, CubicBezier, QuadraticBezier

OUT    = hx('#0D1858')
BLUE_T = hx('#3E70F6')   # top light
BLUE_M = hx('#2353DC')
BLUE_B = hx('#1638AE')   # bottom dark
YEL_L  = hx('#FFE04A')
EYE_SH = hx('#E4EAFA')

SHOULDER_L = (168, 300)
SHOULDER_R = (344, 300)
WING_BASE_R = 24
WING_LEN = 118
EYE_L = (210, 190)
EYE_R = (302, 190)
EYE_D = 118

def gf(stops, s, e, o=100):
    flat = []
    for off, c in stops:
        flat += [off, c[0], c[1], c[2]]
    return {"ty": "gf", "nm": "gradient", "o": st(o), "r": 1, "t": 1,
            "s": st(list(s)), "e": st(list(e)), "g": {"p": len(stops), "k": st(flat)}}

def blob(shapes, grad, outline_w=9, nm="blob", inner=None):
    """Union look: dark outline underlay for all shapes, then each shape filled separately on top."""
    under = gr([gr([x, sk(OUT, outline_w), fl(OUT)], "o") for x in shapes()], nm + "-outline")
    top = gr([gr([x, grad() if callable(grad) else fl(grad)], "f") for x in shapes()], nm + "-fill")
    return [top, under]

# --- logo from the supplied SVG ---
LOGO_F = ("M128.535 27.113C115.967 27.1525 101.145 27.1785 101.145 27.1785V27.1921H95.5254L95.5381 27.1785C95.5296 "
          "27.1785 95.1579 27.1834 94.4238 27.1921C90.209 27.2053 74.5902 27.2444 58.2373 27.2576H48.4023C26.2041 "
          "27.2577 25.9248 52.667 25.9238 52.7585V133.713C25.9237 133.831 25.8346 133.91 25.7334 133.91H1.03906C1.03919 "
          "133.873 1.17871 93.5255 1.17871 50.4685C1.17871 9.80079 37.6187 2.46708 44.5928 1.44019C45.2594 1.34364 "
          "45.9304 1.29565 46.6055 1.29565H128.535V27.113ZM83.0283 56.8699C88.0657 56.87 92.1542 61.1224 92.1543 "
          "66.3621V71.5759C92.1542 76.8288 88.0657 81.0807 83.0283 81.0808H54.0811C49.031 81.0807 44.9425 76.8287 "
          "44.9424 71.5759V66.3621C44.9425 61.1224 49.031 56.87 54.0811 56.8699H83.0283Z")
LOGO_J = ("M73.1582 115.412C73.1582 115.412 87.8784 115.28 94.0678 115.28C102.814 115.03 109.712 107.289 109.282 "
          "94.2551V78.4304H128.535C128.535 78.4304 128.53 92.2935 128.53 101.68C128.745 114.122 117.518 133.159 93.533 "
          "134.093L73.1582 133.909V115.412Z")

def svg_to_shapes(d, cx, cy, scale, ox=64.77, oy=67.69):
    tx = lambda z: [round(cx + (z.real - ox) * scale, 3), round(cy + (z.imag - oy) * scale, 3)]
    shapes = []
    for sub in parse_path(d).continuous_subpaths():
        v, i, o = [], [], []
        for seg in sub:
            if isinstance(seg, QuadraticBezier):
                seg = CubicBezier(seg.start, seg.start + 2 / 3 * (seg.control - seg.start),
                                  seg.end + 2 / 3 * (seg.control - seg.end), seg.end)
            p0 = tx(seg.start)
            if not v:
                v.append(p0); i.append([0, 0]); o.append([0, 0])
            if isinstance(seg, CubicBezier):
                c1, c2 = tx(seg.control1), tx(seg.control2)
                o[-1] = [c1[0] - p0[0], c1[1] - p0[1]]
                p1 = tx(seg.end)
                v.append(p1); i.append([c2[0] - p1[0], c2[1] - p1[1]]); o.append([0, 0])
            else:
                v.append(tx(seg.end)); i.append([0, 0]); o.append([0, 0])
        if len(v) > 1 and abs(v[0][0] - v[-1][0]) < 0.01 and abs(v[0][1] - v[-1][1]) < 0.01:
            i[0] = i[-1]; v.pop(); i.pop(); o.pop()
        shapes.append(sh(v, i, o))
    return shapes

def logo(c, scale=0.66):
    x, y = c
    f = svg_to_shapes(LOGO_F, x, y, scale)
    j = svg_to_shapes(LOGO_J, x, y, scale)
    ty = lambda v: y + (v - 67.69) * scale
    blue = gr(f + [gf([(0, hx('#1C6BFC')), (1, hx('#082EA2'))], (x, ty(1.3)), (x, ty(133.9)))], "logo-F")
    yel = gr(j + [gf([(0, hx('#FADF01')), (1, hx('#DA9400'))], (x, ty(78.4)), (x, ty(147.8)))], "logo-J")
    return [yel, blue]

# --- head ---
EAR_L = [[136, 156], [150, 62], [216, 98]]

def ear_shape(pts, flip=False):
    a, b, c = pts
    f = -1 if flip else 1
    return sh([a, b, c], i=[[0, 0], [-4 * f, 18], [-24 * f, -8]], o=[[2 * f, -32], [22 * f, 2], [0, 0]])

HEAD_C, HEAD_S = (256, 194), (282, 226)

def head_grad():
    return gf([(0, BLUE_T), (0.55, BLUE_M), (1, BLUE_M)], (256, 80), (256, 300))

def head_fill_shapes():
    shapes = lambda: [ear_shape(EAR_L), ear_shape(mirror(EAR_L), True), el(HEAD_C, HEAD_S)]
    fill = gr([gr([x, sk(BLUE_T, 8), fl(BLUE_T)], "f") if k < 2 else gr([x, head_grad()], "f")
               for k, x in enumerate(shapes())], "head-fill")
    inner_ear = gr([ear_shape([[150, 138], [156, 78], [200, 104]]), ear_shape(mirror([[150, 138], [156, 78], [200, 104]]), True),
                    fl(BLUE_M, 70)], "inner-ear")
    shine = gr([el((0, 0), (70, 22)), fl(WHITE, 9)], "shine", p=(200, 116), r=-14)
    return [shine, inner_ear, fill]

def head_outline_shapes():
    shapes = [ear_shape(EAR_L), ear_shape(mirror(EAR_L), True), el(HEAD_C, HEAD_S)]
    return [gr([gr([x, sk(OUT, 10), fl(OUT)], "o") for x in shapes], "head-outline")]

# --- body ---
BODY_C, BODY_S = (256, 352), (250, 218)

def body_shapes():
    s = lambda: [el(BODY_C, BODY_S)]
    return [gr(s() + [gf([(0, BLUE_M), (1, BLUE_B)], (256, 250), (256, 462))], "body-fill"),
            gr(s() + [sk(OUT, 10), fl(OUT)], "body-outline")]

def cape_back_shapes():
    v = [[200, 296], [312, 296], [384, 452], [128, 452]]
    i = [[0, 0], [0, 0], [10, -30], [30, 6]]
    o = [[0, 0], [10, 30], [-30, 6], [-10, -30]]
    return [gr([sh(v, i, o), sk(YEL_D, 5),
                gf([(0, hx('#FFC61A')), (1, hx('#E8A300'))], (256, 300), (256, 452))], "cape-back")]

def front_shapes():
    # thick rope collar
    rope = lambda dy=0: sh([[170, 280 + dy], [342, 280 + dy]], o=[[56, 16], [0, 0]], i=[[0, 0], [-56, 16]], closed=False)
    collar_o = gr([rope(), sk(YEL_D, 31)], "collar-outline")
    collar = gr([rope(), sk(YEL, 24)], "collar")
    collar_hl = gr([rope(-6), sk(YEL_L, 6, 80)], "collar-shine")
    knot = gr([rc((256, 296), (40, 32), 11), sk(YEL_D, 3.5),
               gf([(0, YEL_L), (1, YEL)], (256, 280), (256, 312))], "knot")
    knot_line = gr([sh([[246, 288], [246, 304]], closed=False), sh([[266, 288], [266, 304]], closed=False),
                    sk(YEL_D, 2.5, 70)], "knot-lines")
    # cape edges framing the belly
    straps = lambda: [sh([[206, 298], [168, 406], [140, 450]], o=[[-20, 36], [-8, 24], [0, 0]], i=[[0, 0], [8, -36], [8, -14]], closed=False),
                      sh([[306, 298], [344, 406], [372, 450]], o=[[20, 36], [8, 24], [0, 0]], i=[[0, 0], [-8, -36], [-8, -14]], closed=False)]
    strap = gr(straps() + [sk(YEL, 12)], "cape-edge")
    strap_o = gr(straps() + [sk(YEL_D, 18)], "cape-edge-outline")
    belly = gr([el((256, 378), (180, 152)),
                gf([(0, WHITE), (0.7, WHITE), (1, EYE_SH)], (256, 302), (256, 454))], "belly")
    return [knot_line, knot, collar_hl, collar, collar_o, strap, strap_o] + logo((256, 380)) + [belly]

def wing_path(side):
    f = 1 if side == 'R' else -1
    v = [[0, -6], [36 * f, 42], [8 * f, WING_LEN], [-24 * f, 48]]
    i = [[-16 * f, 0], [0, -26], [16 * f, -18], [-4 * f, 34]]
    o = [[18 * f, 0], [0, 34], [-8 * f, -10], [2 * f, -28]]
    return sh(v, i, o)

def wing_shapes(side):
    sx, sy = SHOULDER_L if side == 'L' else SHOULDER_R
    f = 1 if side == 'R' else -1
    rot = WING_BASE_R if side == 'L' else -WING_BASE_R
    feathers = gr([sh([[14 * f, 84], [2 * f, 100]], closed=False), sh([[22 * f, 66], [12 * f, 82]], closed=False),
                   sk(OUT, 3, 40)], "feathers")
    fill = gr([wing_path(side), gf([(0, BLUE_T), (1, BLUE_B)], (0, 0), (0, WING_LEN))], "wing-fill")
    outline = gr([wing_path(side), sk(OUT, 9), fl(OUT)], "wing-outline")
    return [gr([feathers, fill, outline], "wing", p=(sx, sy), r=rot)]

def foot_shapes(c):
    x, y = c
    s = lambda: [el((x - 15, y + 3), (22, 24)), el((x, y + 5), (22, 26)), el((x + 15, y + 3), (22, 24)),
                 el((x, y - 3), (46, 22))]
    toes = gr([sh([[x - 7.5, y + 4], [x - 7.5, y + 13]], closed=False), sh([[x + 7.5, y + 4], [x + 7.5, y + 13]], closed=False),
               sk(YEL_D, 2.5, 80)], "toes")
    grad = lambda: gf([(0, YEL_L), (1, YEL)], (x, y - 12), (x, y + 16))
    return [toes] + blob(s, grad, 7, "foot")

# --- face: merged eye mask ---
def eye_parts(c, pupil_dir, happy, look, nm):
    cx, cy = c
    pc = (cx + pupil_dir, cy + 6)
    pupil = gr([
        gr([el((pc[0] + 10, pc[1] + 10), (8, 8)), fl(WHITE)], "hl2"),
        gr([el((pc[0] - 9, pc[1] - 10), (18, 18)), fl(WHITE)], "hl1"),
        gr([el(pc, (58, 58)), fl(INK)], "pupil"),
    ], nm + "-pupil", a=pc, p=look['p'], s=look['s'], o=look['o'])
    arc = gr([sh([[cx - 26, cy + 9], [cx, cy - 13], [cx + 26, cy + 9]],
                 i=[[0, 0], [-15, 0], [-4, -10]], o=[[4, -10], [15, 0], [0, 0]], closed=False),
              sk(INK, 9)], nm + "-happy", a=(cx, cy), p=(cx, cy), s=happy['s'], o=happy['o'])
    return [arc, pupil]

def face_shapes(spec, N):
    beak = gr([sh([[238, 236], [274, 236], [256, 270]],
                  i=[[0, -8], [8, -6], [8, 0]], o=[[-8, -6], [0, 8], [-8, 0]]), sk(YEL_D, 3.5),
               gf([(0, YEL_L), (1, hx('#F2AE00'))], (256, 232), (256, 270))], "beak")
    parts = []
    for side, c, pdir in (('L', EYE_L, 7), ('R', EYE_R, -7)):
        closed = spec.get('closed_' + side, spec.get('closed', []))
        look, happy = eye_anim(closed, (c[0] + pdir, c[1] + 6), spec.get('look'), N)
        parts += eye_parts(c, pdir, happy, look, 'eye-' + side)
    mask = lambda: [el(EYE_L, (EYE_D, EYE_D)), el(EYE_R, (EYE_D, EYE_D))]
    eye_grad = lambda: gf([(0, WHITE), (0.75, WHITE), (1, EYE_SH)], (256, 140), (256, 250))
    return [beak] + parts + blob(mask, eye_grad, 9, "eye-mask")
