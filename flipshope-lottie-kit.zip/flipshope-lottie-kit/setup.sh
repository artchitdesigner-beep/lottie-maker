#!/usr/bin/env bash
# Installs everything the Flipshope Lottie kit needs. Run from the kit folder.
set -e
cd "$(dirname "$0")"
pip install -q lottie svgpathtools fonttools brotli playwright pillow --break-system-packages 2>/dev/null || \
  pip install -q lottie svgpathtools fonttools brotli playwright pillow
[ -f package.json ] || npm init -y >/dev/null
npm i --silent lottie-web@5.12.2 @iconify-json/fluent-emoji-flat @fontsource/baloo-2 @fontsource/figtree
python3 -c "from playwright.sync_api import sync_playwright as s; p=s().start(); p.chromium.launch().close(); p.stop()" 2>/dev/null \
  || echo "note: no bundled Chromium found; check.py will try /usr/bin/google-chrome"
mkdir -p out json
echo "Flipshope Lottie kit ready."
